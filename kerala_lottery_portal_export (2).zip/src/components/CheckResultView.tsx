/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Search, Loader2, CheckCircle2, AlertCircle, XCircle, Trophy, Ticket, Calendar, Crown, Star, Sparkles } from "lucide-react";
import { TicketPurchase } from "../types";

interface CheckResultViewProps {
  initialPhone?: string;
}

export default function CheckResultView({ initialPhone = "" }: CheckResultViewProps) {
  const [phone, setPhone] = React.useState(initialPhone);
  const [loading, setLoading] = React.useState(false);
  const [searched, setSearched] = React.useState(false);
  const [purchases, setPurchases] = React.useState<TicketPurchase[]>([]);
  const [errorMsg, setErrorMsg] = React.useState<string | null>(null);

  const [winners, setWinners] = React.useState<any[]>([]);
  const [loadingWinners, setLoadingWinners] = React.useState(false);

  const [settings, setSettings] = React.useState({
    whatsappNumber: "+91 94460 01234"
  });

  // Standard prize tiers structure
  const PRIZE_TIERS = React.useMemo(() => [
    { position: "1st Position", prizeText: "1st Prize (Rs. 25 Crore)", badgeColor: "bg-red-500/20 text-red-450 border-red-500/40 font-black", ticketCount: 1 },
    { position: "2nd Position", prizeText: "2nd Prize (Rs. 10 Crore)", badgeColor: "bg-amber-500/20 text-amber-400 border-amber-500/40 font-black", ticketCount: 2 },
    { position: "3rd Position", prizeText: "3rd Prize (Rs. 75 Lakh)", badgeColor: "bg-orange-500/20 text-orange-400 border-orange-500/40 font-bold", ticketCount: 3 },
    { position: "4th Position", prizeText: "4th Prize (Rs. 25 Lakh)", badgeColor: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30 font-semibold", ticketCount: 4 },
    { position: "5th Position", prizeText: "5th Prize (Rs. 12 Lakhs)", badgeColor: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30 font-medium", ticketCount: 6 },
    { position: "6th Position", prizeText: "6th Prize (Rs. 8 Lakh)", badgeColor: "bg-green-500/20 text-green-400 border-green-500/30 text-[11px]", ticketCount: 8 },
    { position: "7th Position", prizeText: "7th Prize (Rs. 5 Lakh)", badgeColor: "bg-cyan-500/20 text-cyan-400 border-cyan-500/30 text-[11px]", ticketCount: 10 },
    { position: "8th Position", prizeText: "8th Prize (Rs. 3 Lakh)", badgeColor: "bg-blue-500/20 text-blue-400 border-blue-500/30 text-[11px]", ticketCount: 12 },
    { position: "9th Position", prizeText: "9th Prize (Rs. 2 Lakh)", badgeColor: "bg-indigo-500/20 text-indigo-400 border-indigo-500/30 text-[11px]", ticketCount: 15 },
    { position: "10th Position", prizeText: "10th Prize (Rs. 75 Thousand)", badgeColor: "bg-purple-500/20 text-purple-400 border-purple-500/30 text-[11px]", ticketCount: 20 }
  ], []);

  const getCustomerWinningTicketsForTier = React.useCallback((tierIndex: number) => {
    const winningSlips: { ticket: string; prize: string } = {} as any;
    const finalWinningSlips: { ticket: string; prize: string }[] = [];
    
    purchases.forEach(item => {
      if (item.status === "verified" && item.winningPrize && item.winningPrize !== "Result Pending") {
        const upPrize = item.winningPrize.toUpperCase();
        
        let matchesTier = false;
        
        const tierKeywordsMap = [
          ["1ST", "FIRST"],
          ["2ND", "SECOND"],
          ["3RD", "THIRD"],
          ["4TH", "FOURTH"],
          ["5TH", "FIFTH"],
          ["6TH", "SIXTH"],
          ["7TH", "SEVENTH"],
          ["8TH", "EIGHTH"],
          ["9TH", "NINTH"],
          ["10TH", "TENTH"]
        ];

        if (tierIndex >= 0 && tierIndex < 10) {
          const keywords = tierKeywordsMap[tierIndex];
          if (keywords) {
            matchesTier = keywords.some(kw => upPrize.includes(kw));
          }
        }
        
        if (matchesTier) {
          let matchedTicket = "";
          const words = item.winningPrize.split(/\s+/);
          const ticketRegex = /[A-Z]{2}-\d{6}/i;
          for (const word of words) {
            if (ticketRegex.test(word.trim())) {
              matchedTicket = word.trim().replace(/[.,()]/g, "").toUpperCase();
              break;
            }
          }
          
          if (!matchedTicket && item.ticketNumber) {
            matchedTicket = item.ticketNumber.split(",")[0]?.trim().toUpperCase();
          }
          
          if (matchedTicket) {
            finalWinningSlips.push({ ticket: matchedTicket, prize: item.winningPrize });
          }
        }
      }
    });
    return finalWinningSlips;
  }, [purchases]);

  const dummyTicketsForTier = React.useMemo(() => {
    const tiersData: { [key: number]: string[] } = {};
    const existingTickets = purchases.flatMap(p => p.ticketNumber ? p.ticketNumber.split(",").map(t => t.trim().toUpperCase()) : []);

    let seed = 127;
    // Matching ticketCount sizes for standard Kerala official display
    [1, 2, 3, 4, 6, 8, 10, 12, 15, 20].forEach((count, tierIndex) => {
      const list: string[] = [];
      while (list.length < count) {
        seed = (seed * 19 + 43) % 999983;
        const series = ["WA", "WB", "WC", "WD", "KL", "KM", "KN", "KP", "BR", "BS", "BT", "BU", "CG", "CH", "CJ", "CK", "XY", "XZ"];
        const s = series[seed % series.length];
        const digits = String((204958 + seed * 9437) % 899999 + 100000);
        const ticket = `${s}-${digits}`;
        
        if (!list.includes(ticket) && !existingTickets.includes(ticket)) {
          list.push(ticket);
        }
      }
      tiersData[tierIndex] = list;
    });
    
    return tiersData;
  }, [purchases]);

  const parsePrizeDetails = React.useCallback((winningPrize: string) => {
    if (!winningPrize) return { position: "Prize", amountText: "Result Pending" };
    const prizeLower = winningPrize.toLowerCase();
    let position = "Winner";
    let amountText = winningPrize;

    if (prizeLower.includes("1st") || prizeLower.includes("first")) {
      position = "1st Winner";
      amountText = "25 Crore";
    } else if (prizeLower.includes("2nd") || prizeLower.includes("second")) {
      position = "2nd Winner";
      amountText = "10 Crore";
    } else if (prizeLower.includes("3rd") || prizeLower.includes("third")) {
      position = "3rd Winner";
      amountText = "75 Lakh";
    } else if (prizeLower.includes("4th") || prizeLower.includes("fourth")) {
      position = "4th Winner";
      amountText = "25 Lakh";
    } else if (prizeLower.includes("5th") || prizeLower.includes("fifth")) {
      position = "5th Winner";
      amountText = "12 Lakhs";
    } else if (prizeLower.includes("6th") || prizeLower.includes("sixth")) {
      position = "6th Winner";
      amountText = "8 Lakh";
    } else if (prizeLower.includes("7th") || prizeLower.includes("seventh")) {
      position = "7th Winner";
      amountText = "5 Lakh";
    } else if (prizeLower.includes("8th") || prizeLower.includes("eighth")) {
      position = "8th Winner";
      amountText = "3 Lakh";
    } else if (prizeLower.includes("9th") || prizeLower.includes("ninth")) {
      position = "9th Winner";
      amountText = "2 Lakh";
    } else if (prizeLower.includes("10th") || prizeLower.includes("tenth")) {
      position = "10th Winner";
      amountText = "75 Thousand";
    }

    try {
      const matchPos = winningPrize.match(/(\d+(st|nd|rd|th))\s+Prize/i);
      if (matchPos && matchPos[1]) {
        position = `${matchPos[1].toLowerCase()} winner`.replace(/\b\w/g, c => c.toUpperCase());
      }
      
      const matchAmountInParen = winningPrize.match(/\(([^)]+)\)/);
      if (matchAmountInParen && matchAmountInParen[1]) {
        amountText = matchAmountInParen[1].replace(/Rs\.?\s*/i, "").trim().toUpperCase();
      } else {
        const cleaned = winningPrize.replace(/\d+(st|nd|rd|th)\s+Prize\s*/i, "").trim();
        if (cleaned) {
          amountText = cleaned.toUpperCase();
        }
      }
    } catch (e) {
      // ignore
    }

    return { position, amountText };
  }, []);

  React.useEffect(() => {
    fetch("/api/settings")
      .then((res) => res.json())
      .then((data) => {
        setSettings({
          whatsappNumber: data.whatsappNumber || "+91 94460 01234"
        });
      })
      .catch((err) => console.error("Error loading settings in CheckResultView:", err));
  }, []);

  React.useEffect(() => {
    // Fetch live winners list
    setLoadingWinners(true);
    fetch("/api/winners")
      .then((res) => res.json())
      .then((data) => {
        setWinners(Array.isArray(data) ? data : []);
      })
      .catch((err) => console.error("Error loading winners in CheckResultView:", err))
      .finally(() => setLoadingWinners(false));
  }, []);

  React.useEffect(() => {
    if (initialPhone) {
      setPhone(initialPhone);
      fetchResults(initialPhone);
    }
  }, [initialPhone]);

  const fetchResults = async (searchPhone: string) => {
    if (!searchPhone.trim()) return;
    setLoading(true);
    setErrorMsg(null);
    setSearched(true);

    try {
      const response = await fetch(`/api/results?phone=${encodeURIComponent(searchPhone.trim())}`);
      if (!response.ok) {
        throw new Error("Failed to scan draw database archives.");
      }
      const data = await response.json();
      setPurchases(data);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err?.message || "Error establishing connection. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone.trim()) {
      alert("Please enter your registered telephone number.");
      return;
    }
    fetchResults(phone);
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 md:px-8 space-y-12 animate-fade-in" id="result-view-container">
      {/* View Header */}
      <div className="text-center space-y-3">
        <span className="inline-flex items-center space-x-1 rounded-full bg-emerald-950 px-3 py-1 text-xs font-semibold text-[#a3e635]">
          <Trophy className="h-4 w-4 text-amber-500" />
          <span>Real-time Ticket Ledger & Winnings Lookup</span>
        </span>
        <h1 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
          Check Winnings & <span className="text-emerald-400">Allocated Tickets</span>
        </h1>
        <p className="mx-auto max-w-xl text-sm text-emerald-250">
          Enter your billing telephone number to verify administrative screenshot approvals, retrieve official physical serial allocations, and look up lottery prizes.
        </p>
      </div>

      {/* Input Form Search Card */}
      <div className="mx-auto max-w-xl rounded-2xl border border-emerald-990 bg-[#022c22]/50 p-6 shadow-md">
        <form onSubmit={handleSubmit} className="space-y-4 text-xs text-left">
          <div className="space-y-1.5">
            <label className="text-emerald-300 font-bold block">Enter Registered WhatsApp Number</label>
            <div className="relative">
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="e.g. +91 94460 00000"
                className="w-full h-11 rounded-xl border border-emerald-800 bg-[#021f18] pl-4 pr-12 text-white placeholder-emerald-800 focus:outline-none focus:border-emerald-500 text-xs text-center font-bold tracking-wide"
              />
              <div className="absolute right-3.5 top-3.5 text-emerald-500">
                {loading ? <Loader2 className="h-4.5 w-4.5 animate-spin" /> : <Search className="h-4.5 w-4.5" />}
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center space-x-2 rounded-xl bg-amber-500 hover:bg-[#b58c07] active:scale-95 disabled:opacity-60 transition text-slate-950 px-4 py-2.5 h-11 text-xs font-bold shadow-md"
          >
            <span>DISPATCH DATABASE SCAN</span>
          </button>
        </form>
      </div>

      {/* Database Search Results Display */}
      <div className="space-y-6">
        {loading && (
          <div className="flex flex-col items-center justify-center py-12 space-y-3">
            <Loader2 className="h-8 w-8 text-[#a3e635] animate-spin" />
            <p className="text-xs text-emerald-300 font-medium">Scanning u194092554_koll registry tables...</p>
          </div>
        )}

        {errorMsg && (
          <div className="rounded-xl border border-red-900 bg-red-950/20 p-5 flex items-start space-x-3 text-red-200 text-xs">
            <AlertCircle className="h-5 w-5 shrink-0 text-red-500" />
            <div className="space-y-1">
              <p className="font-bold">Transmission Interrupted</p>
              <p>{errorMsg}</p>
            </div>
          </div>
        )}

        {searched && !loading && !errorMsg && (
          <div className="space-y-6">
            {purchases.length === 0 ? (
              <div className="rounded-2xl border border-emerald-900/60 bg-emerald-950/20 p-12 text-center space-y-4">
                <AlertCircle className="h-12 w-14 text-amber-500 mx-auto" />
                <div className="space-y-1.5">
                  <h3 className="text-md font-bold text-white">No Assigned Purchases Recorded</h3>
                  <p className="text-xs text-emerald-300 max-w-sm mx-auto leading-relaxed">
                    We couldn't locate any ticket booking queue matching <strong>{phone}</strong>. If you just placed an order, please wait 5-10 minutes for regional synchronization.
                  </p>
                </div>
                <button 
                  onClick={() => {
                    setPhone("");
                    setSearched(false);
                  }}
                  className="rounded-lg bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2 transition"
                >
                  Clear & Try Again
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b border-emerald-900 pb-2">
                  <h3 className="text-sm font-bold text-[#a3e635] uppercase tracking-wider">
                    📋 Active Bookings Found ({purchases.length})
                  </h3>
                  <span className="text-[10px] text-emerald-400 font-medium">u194092554_koll database ledger</span>
                </div>

                {purchases.map((item) => (
                  <div 
                    key={item.id}
                    className="rounded-2xl border border-emerald-900 bg-emerald-950/40 p-6 md:p-8 flex flex-col md:flex-row gap-6 justify-between items-stretch shadow-md transition hover:border-emerald-700"
                  >
                    {/* Purchase particulars info block */}
                    <div className="space-y-4 flex-1 text-left">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="rounded bg-emerald-900/70 border border-emerald-800/60 px-2 py-0.5 text-[10px] font-bold text-emerald-300">
                          {item.packageName}
                        </span>
                        
                        {item.status === "pending" && (
                          <span className="inline-flex items-center space-x-1 rounded bg-amber-950/80 text-amber-500 text-[10px] font-bold px-2 py-0.5 border border-amber-900/60">
                            <Loader2 className="h-3 w-3 animate-spin" />
                            <span>Payment Verifying</span>
                          </span>
                        )}

                        {item.status === "rejected" && (
                          <span className="inline-flex items-center space-x-1 rounded bg-red-950/80 text-red-500 text-[10px] font-bold px-2 py-0.5 border border-red-900/60">
                            <XCircle className="h-3 w-3" />
                            <span>Verification Rejected</span>
                          </span>
                        )}

                        {item.status === "verified" && (
                          <span className="inline-flex items-center space-x-1 rounded bg-emerald-950/80 text-[#a3e635] text-[10px] font-bold px-2 py-0.5 border border-emerald-800/60">
                            <CheckCircle2 className="h-3 w-3" />
                            <span>Verified Ticket Slips Issued</span>
                          </span>
                        )}
                      </div>

                      <div className="grid grid-cols-2 gap-y-2 gap-x-4 text-[11px] text-emerald-200">
                        <div>
                          <p className="text-emerald-450 font-semibold uppercase text-[9px]">Buyer Name</p>
                          <p className="font-bold text-white text-xs">{item.name}</p>
                        </div>
                        <div>
                          <p className="text-emerald-450 font-semibold uppercase text-[9px]">Registered Phone</p>
                          <p className="font-bold text-white text-xs">{item.phone}</p>
                        </div>
                        <div>
                          <p className="text-emerald-450 font-semibold uppercase text-[9px]">Quantity Booked</p>
                          <p className="font-bold text-white">{item.ticketCount} Slips</p>
                        </div>
                        <div>
                          <p className="text-emerald-450 font-semibold uppercase text-[9px]">Total Amount</p>
                          <p className="font-bold text-amber-500">Rs. {item.amount}</p>
                        </div>
                        <div className="col-span-2">
                          <p className="text-emerald-450 font-semibold uppercase text-[9px]">Submitted Date & State</p>
                          <p>{item.state} • {new Date(item.createdAt).toLocaleDateString()} {new Date(item.createdAt).toLocaleTimeString()}</p>
                        </div>
                      </div>

                      {/* Display warning or instruction depending on status */}
                      <div className="rounded-lg bg-emerald-950/80 p-3.5 border border-emerald-900 text-[11px] leading-relaxed">
                        {item.status === "pending" && (
                          <p className="text-amber-500/90">
                            We have received your UPI screenshot upload. Our accounting department in Vikas Bhavan, Trivandrum is verifying the transaction ID. Once cleared, we will assign your serial tickets and post them here immediately! Checked back within an hour.
                          </p>
                        )}
                        {item.status === "rejected" && (
                          <p className="text-red-400">
                            We were unable to verify this payment against our Bank API registers. This might happen if the screenshot was blurred or transaction was canceled. Please re-submit your booking or contact our WhatsApp support desk for instant handovers.
                          </p>
                        )}
                        {item.status === "verified" && (
                          <div className="space-y-2 text-emerald-100">
                            <p className="text-emerald-200">
                              🎉 <strong>Congratulations!</strong> Your transaction has been cleared securely. The physical government paper tickets are locked in our high-security locker room, registered in your name.
                            </p>
                            <div className="rounded-md bg-emerald-900/30 p-2.5 border border-emerald-800 text-[10px] text-emerald-300">
                              <em>Claim Rule: Keep this online slip safely. For payouts, search entries and click our claim assist buttons to instruct district cash distribution banks.</em>
                            </div>
                          </div>
                        )}
                      </div>
                    {item.status === "verified" && item.winningPrize && item.winningPrize !== "Result Pending" && item.winningPrize !== "None" ? (
                      /* REDESIGNED SCREENSHOT-MATCHING WINNER CARD IN HIGH RESOLUTION */
                      <div id={`winner-coupon-${item.id}`} className="w-full md:w-[350px] flex flex-col justify-between items-center bg-gradient-to-b from-[#021f18] to-[#01140f] rounded-3xl border-4 border-amber-400 p-5 text-center relative overflow-hidden transition-all duration-300 shadow-2xl shrink-0">
                        {/* Shimmer/Starry overlays */}
                        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-amber-400/5 via-transparent to-transparent pointer-events-none"></div>

                        {/* Sparkles, starry micro-effects */}
                        <div className="absolute top-2 left-2 opacity-30 select-none animate-spin-slow pointer-events-none">
                          <Sparkles className="h-4 w-4 text-amber-400" />
                        </div>
                        <div className="absolute top-2 right-2 opacity-30 select-none animate-spin-slow pointer-events-none">
                          <Sparkles className="h-4 w-4 text-amber-400" />
                        </div>

                        {/* 1. Official Seal with flanking wings & floating gold Crown */}
                        <div className="relative mt-2 flex flex-col items-center">
                          {/* Crown directly floating above emblem */}
                          <div className="mb-2 animate-bounce duration-1000 select-none filter drop-shadow-[0_2px_8px_rgba(245,158,11,0.5)]">
                            <Crown className="h-10 w-10 text-amber-400" fill="#f59e0b" />
                          </div>

                          {/* Outer circular gold border */}
                          <div className="w-24 h-24 rounded-full border-4 border-amber-400 bg-gradient-to-br from-[#0c2409] via-[#022c22] to-[#011410] flex flex-col items-center justify-center p-1.5 shadow-xl relative">
                            {/* Inner dashed ring */}
                            <div className="absolute inset-1 rounded-full border border-dashed border-amber-400/40"></div>
                            <p className="text-[7px] font-black text-[#a3e635] tracking-tighter uppercase leading-none text-center">
                              KERALA STATE
                            </p>
                            <div className="text-[10px] text-amber-300 font-bold my-1 tracking-widest leading-none select-none">
                              🐘 🏛️ 🐘
                            </div>
                            <p className="text-[6px] font-bold text-white tracking-widest uppercase leading-none text-center">
                              GOVT LOTTERY
                            </p>
                          </div>
                        </div>

                        {/* 2. Shaded golden banner with Congratulations */}
                        <div className="w-full mt-4 space-y-2">
                          <div className="relative h-6 w-full bg-gradient-to-r from-amber-600 via-amber-400 to-amber-600 rounded-md shadow-md flex items-center justify-center select-none">
                            <span className="text-[10px] font-black text-slate-950 uppercase tracking-widest">
                              Official verification ledger
                            </span>
                          </div>

                          {/* congratulations text */}
                          <p className="text-2xl font-serif font-black text-transparent bg-clip-text bg-gradient-to-r from-red-400 via-amber-400 to-yellow-300 tracking-wide uppercase text-center drop-shadow-[0_1.5px_2px_rgba(0,0,0,0.8)]">
                            Congratulations
                          </p>
                        </div>

                        {/* 3. Subtitle "⭐ You X Winner ⭐" with gold stars */}
                        <div className="mt-3">
                          <p className="text-[#a3e635] text-[13px] font-black uppercase tracking-wider flex items-center justify-center gap-1">
                            <Star className="h-3.5 w-3.5 text-amber-400" fill="#f59e0b" />
                            <span>You {parsePrizeDetails(item.winningPrize).position}</span>
                            <Star className="h-3.5 w-3.5 text-amber-400" fill="#f59e0b" />
                          </p>
                        </div>

                        {/* 4. Buyer Particulars Block */}
                        <div className="mt-4 space-y-1 w-full text-center">
                          <p className="text-white font-black text-xl tracking-tight uppercase">
                            {item.name}
                          </p>
                          <p className="text-[#a3e635] font-mono text-sm font-bold tracking-wider opacity-90">
                            {item.phone}
                          </p>
                          <p className="inline-block mt-2 font-mono text-base font-extrabold text-amber-450 uppercase bg-[#01140f] border border-emerald-900 px-3.5 py-1.5 rounded-lg tracking-widest select-all">
                            🎟️ {item.ticketNumber?.split(",")[0]?.trim()}
                          </p>
                        </div>

                        {/* 5. Thick Green Divider Line */}
                        <div className="w-4/5 mx-auto h-2 rounded-full bg-gradient-to-r from-emerald-800 via-emerald-500 to-emerald-800 my-4 shadow-inner"></div>

                        {/* 6. Arched Coupon Card Inset (white background!) */}
                        <div className="w-full rounded-2xl bg-white border-2 border-emerald-900/10 p-5 shadow-xl relative overflow-hidden">
                          {/* Inner serrated decorative shapes */}
                          <div className="absolute left-[-6px] top-1/2 -translate-y-1/2 w-3.5 h-3.5 bg-[#01140f] rounded-full"></div>
                          <div className="absolute right-[-6px] top-1/2 -translate-y-1/2 w-3.5 h-3.5 bg-[#01140f] rounded-full"></div>

                          {/* Inner text content */}
                          <div className="space-y-2">
                            <p className="text-[11px] font-black text-slate-800 uppercase tracking-widest flex items-center justify-center gap-1.5">
                              <span>🏆</span>
                              <span>{parsePrizeDetails(item.winningPrize).position}</span>
                              <span>🏆</span>
                            </p>

                            {/* Huge energetic red cash amount */}
                            <p className="text-4xl sm:text-5xl font-black text-rose-600 tracking-tight text-center drop-shadow-sm uppercase leading-none my-1">
                              {parsePrizeDetails(item.winningPrize).amountText}
                            </p>

                            {/* Contact & Drawing Date details */}
                            <div className="pt-2 border-t border-slate-200 text-[10px] text-slate-600 space-y-0.5">
                              <p className="font-semibold select-all">
                                Contact: <strong className="text-slate-900">{settings.whatsappNumber || "+91 94460 01234"}</strong>
                              </p>
                              <p>
                                Date: <strong className="text-slate-900 uppercase">{new Date(item.createdAt).toLocaleDateString("en-IN")}</strong>
                              </p>
                            </div>
                          </div>
                        </div>

                        {/* 7. Pulse Badge & Big Claim CTA Button */}
                        <div className="mt-4 w-full space-y-3">
                          {/* Pulse Badge */}
                          <div className="flex items-center justify-center">
                            <div className="inline-flex items-center space-x-1 px-3 py-1 rounded-full bg-red-650 border border-red-500/35 text-white font-extrabold text-[9px] tracking-widest uppercase shadow-md shadow-red-950/20">
                              <span className="block h-1.5 w-1.5 rounded-full bg-white animate-pulse"></span>
                              <span>LIVE VERIFIED</span>
                            </div>
                          </div>

                          {/* WhatsApp claim button */}
                          <a 
                            href={`https://wa.me/${(settings.whatsappNumber || "").replace(/[^0-9]/g, "")}?text=${encodeURIComponent(
                              `Hello regional state lottery support desk, I have verified my lottery coupon result on your live ledger! My phone is ${item.phone}, name is ${item.name}, and my winning ticket number(s) are: ${item.ticketNumber}. Kindly register and process my prize claim of ${item.winningPrize} immediately. Thank you.`
                            )}`}
                            target="_blank"
                            rel="noreferrer"
                            className="w-full inline-flex items-center justify-center space-x-2 py-3 bg-[#25d366] hover:bg-[#1db455] text-slate-950 font-black rounded-xl text-xs tracking-wider transition active:scale-95 shadow-lg"
                          >
                            <Trophy className="h-4 w-4 stroke-[2.5]" />
                            <span>CLAIM PRIZE VIA WHATSAPP</span>
                          </a>

                          {/* View document check */}
                          {item.screenshotPath && (
                            <p className="text-[9.5px] text-emerald-450 font-medium">
                              <a href={item.screenshotPath} target="_blank" rel="noreferrer" className="hover:underline">
                                View Submitted Payment Proof
                              </a>
                            </p>
                          )}
                        </div>
                      </div>
                    ) : (
                      /* Standard card container when result is pending or normal */
                      <div className="w-full md:w-80 flex flex-col justify-between items-center bg-[#01251e] rounded-2xl border border-emerald-800 p-6 text-center relative overflow-hidden transition-all duration-300 shadow-xl hover:border-emerald-600">
                        <div className="space-y-4 w-full">
                          <div className="flex items-center justify-center space-x-1.5 pb-2 border-b border-emerald-900/60 font-medium">
                            <Ticket className="h-5 w-5 text-emerald-400" />
                            <h4 className="text-[11px] font-bold text-emerald-300 uppercase tracking-widest">
                              OFFICIAL TICKET SERIALS
                            </h4>
                          </div>

                          {item.ticketNumber ? (
                            <div className="space-y-4">
                              <div className="space-y-2 bg-[#011410] rounded-xl py-4 px-3 border border-emerald-900 shadow-inner relative">
                                <div className="absolute left-[-6px] top-1/2 -tune-y-1/2 w-3 h-3 bg-[#01251e] rounded-full border-r border-[#a3e635]/20"></div>
                                <div className="absolute right-[-6px] top-1/2 -tune-y-1/2 w-3 h-3 bg-[#01251e] rounded-full border-l border-[#a3e635]/20"></div>
                                <p className="text-[8px] font-semibold text-emerald-500 tracking-wider uppercase mb-1">Government Registered Coupon No(s).</p>
                                {item.ticketNumber.split(",").map((num, i) => (
                                  <p key={i} className="font-mono text-xs font-extrabold text-[#a3e635] tracking-widest leading-relaxed uppercase bg-emerald-950/40 py-1 px-2.5 rounded border border-emerald-900/45 inline-block mx-1">
                                    🎟️ {num.trim()}
                                  </p>
                                ))}
                              </div>

                              <div className="rounded-xl bg-emerald-950/80 p-3.5 text-center border border-emerald-950/30 shadow-md">
                                <p className="text-[9px] font-semibold text-emerald-450 tracking-widest uppercase">DRAW STATUS</p>
                                <p className="text-xs font-bold font-sans text-[#a3e635] mt-1 flex items-center justify-center space-x-1.5 font-mono">
                                  <Loader2 className="h-4 w-4 shrink-0 text-amber-500 animate-spin" />
                                  <span>{item.winningPrize || "Result Pending"}</span>
                                </p>
                                <p className="text-[9.5px] text-emerald-450 mt-2 max-w-[200px] mx-auto leading-relaxed">
                                  {item.status === "pending" 
                                    ? "Credit validation/screenshot audit in progress. Ticket serial numbers generated successfully!" 
                                    : "Draw matching matches successfully concluded. High-tier winnings indicators will update if drawn."
                                  }
                                </p>
                              </div>
                            </div>
                          ) : (
                            <div className="flex flex-col items-center justify-center h-32 border border-dashed border-emerald-800 rounded-xl bg-emerald-955/30 p-4">
                              <Trophy className="h-6 w-6 text-emerald-600 mb-1.5" />
                              <p className="text-[10px] text-emerald-400 leading-relaxed text-center">
                                {item.status === "rejected" 
                                  ? "This order was marked rejected. Check your verified status with the administrative bureau." 
                                  : "The purchase ledger is awaiting credit validation. Assigned papers are registered once verified."
                                }
                              </p>
                            </div>
                          )}
                        </div>

                        <div className="pt-4 mt-4 border-t border-emerald-900/60 w-full flex items-center justify-between text-[10px] text-emerald-450 font-medium">
                          <span>Receipt Document:</span>
                          <a 
                            href={item.screenshotPath} 
                            target="_blank" 
                            rel="noreferrer" 
                            className="hover:text-amber-400 hover:underline font-bold text-[#a3e635] flex items-center space-x-1"
                          >
                            <span>View Proof File</span>
                            <svg className="h-3 w-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3"/></svg>
                          </a>
                        </div>
                      </div>
                    )}       </div>

                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Dynamic Official Government Draw sheet (1st to 6th Positions) */}
      <div className="border border-amber-500/30 bg-gradient-to-b from-[#02241b] to-[#011a14] rounded-2xl p-6 md:p-8 space-y-8 text-left shrink-0 relative overflow-hidden shadow-xl" id="official-draws-board">
        <div className="absolute right-4 top-4 opacity-[0.03] pointer-events-none">
          <Trophy className="h-44 w-44 text-amber-400 rotate-12" />
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-emerald-900/60 pb-5">
          <div className="space-y-1.5">
            <span className="inline-flex items-center space-x-1.5 rounded-full bg-amber-400/10 border border-amber-400/30 px-3 py-0.5 text-[10px] font-black text-amber-400 uppercase tracking-widest">
              🏛️ Regional Directorate of State Lotteries
            </span>
            <h2 className="text-xl font-black text-white uppercase tracking-tight flex items-center space-x-2">
              <span className="text-amber-500 font-serif">KERALA STATE</span>
              <span>DAILY BUMPER OFFICIAL RESULTS</span>
            </h2>
            <p className="text-[11px] text-emerald-300">
              Authorized regional draw chart compiled per Kerala Gazette regulations. Result resets at <strong>3:00 PM IST Daily</strong>.
            </p>
          </div>
          <div className="flex items-center space-x-2.5 bg-[#011410] border border-emerald-900 px-3 py-1.5 rounded-xl self-start sm:self-center">
            <span className="inline-flex h-2 w-2 rounded-full bg-[#a3e635] animate-ping"></span>
            <span className="text-[10px] uppercase font-black text-emerald-450 tracking-wider">LIVE DIRECTIVE</span>
          </div>
        </div>

        {/* 1st to 6th Positions Official List Sheet */}
        <div className="space-y-5">
          {PRIZE_TIERS.map((tier, tierIdx) => {
            const customerWinners = getCustomerWinningTicketsForTier(tierIdx);
            const dummyList = dummyTicketsForTier[tierIdx] || [];

            return (
              <div 
                key={tierIdx} 
                className={`rounded-xl border p-4 transition-all duration-300 relative overflow-hidden ${
                  customerWinners.length > 0 
                    ? "border-amber-400 bg-gradient-to-r from-[#172506] via-[#021f15] to-[#172506] shadow-md shadow-amber-950/20" 
                    : "border-emerald-900 bg-emerald-950/20"
                }`}
              >
                {/* Visual Background Stamp */}
                <div className="absolute right-4 top-1/2 -translate-y-1/2 select-none pointer-events-none opacity-[0.03] text-[50px] font-black tracking-widest text-emerald-500 uppercase">
                  {tier.position}
                </div>

                <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between relative z-10">
                  {/* Position Badge & Description */}
                  <div className="space-y-1.5 min-w-[240px]">
                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-black border tracking-wider select-none ${tier.badgeColor}`}>
                        {tier.position}
                      </span>
                      {customerWinners.length > 0 && (
                        <span className="bg-[#25d366]/20 border border-[#25d366]/40 text-[#25d366] text-[9px] font-extrabold px-1.5 py-0.5 rounded animate-pulse uppercase tracking-wider">
                          ★ MATCH FOUND
                        </span>
                      )}
                    </div>
                    <p className="text-sm font-black text-white uppercase tracking-tight">{tier.prizeText}</p>
                    <p className="text-[10px] text-emerald-400 font-medium font-sans">Total Assigned Draws: <strong className="font-mono text-amber-500">{tier.ticketCount}</strong></p>
                  </div>

                  {/* Lot Serials numbers lists output */}
                  <div className="flex-1 w-full bg-[#011410] border border-emerald-950 px-3.5 py-3 rounded-xl">
                    <p className="text-[8px] font-bold text-emerald-500 uppercase tracking-widest mb-1.5">Official Drawn Coupon Serials</p>
                    
                    <div className="flex flex-wrap gap-1.5">
                      {/* 1. If Searched Customer is the winner of this position, highlight & draw their ticket on top first! */}
                      {customerWinners.map((w, index) => (
                        <span 
                          key={`cust-${index}`} 
                          className="relative inline-flex items-center space-x-1.5 font-mono text-xs font-black bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 px-3.5 py-1.5 rounded-lg border-2 border-yellow-300 shadow-[0_0_15px_rgba(245,158,11,0.55)] animate-pulse tracking-widest uppercase cursor-pointer select-none"
                          title={`Your winning ticket matching: ${w.prize}`}
                        >
                          <Crown className="h-4 w-4 text-slate-950 fill-slate-950 animate-bounce duration-1000" />
                          <span>🎟️ {w.ticket}</span>
                          <span className="text-[9px] bg-slate-950 text-amber-400 px-1 py-0.5 rounded font-sans font-black ml-1 uppercase">★ YOU WIN</span>
                        </span>
                      ))}

                      {/* 2. Display the official-looking dummy tickets for this tier */}
                      {dummyList.map((tkt, index) => (
                        <span 
                          key={`dummy-${index}`} 
                          className="font-mono text-[11px] font-bold text-emerald-300 uppercase bg-[#022c22]/40 border border-emerald-900/60 px-2 py-1 rounded tracking-widest inline-block select-all hover:bg-emerald-900/10 transition"
                        >
                          🎟️ {tkt}
                        </span>
                      ))}
                    </div>

                    {customerWinners.length > 0 && (
                      <p className="text-[9.5px] text-[#25d366] mt-2 font-black flex items-center space-x-1 animate-pulse">
                        <span>🎉 CONGRATULATIONS! Your verified ticket is listed in the official drawing registers. Click 'CLAIM PRIZE' above to redeem immediately.</span>
                      </p>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
