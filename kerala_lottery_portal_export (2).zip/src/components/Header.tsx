/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Ticket, Search, BookOpen, Info, Mail, ShieldAlert, Award } from "lucide-react";

interface HeaderProps {
  currentPage: string;
  setCurrentPage: (page: string) => void;
  isAdminLoggedIn: boolean;
  onLogoutAdmin: () => void;
}

export default function Header({ currentPage, setCurrentPage, isAdminLoggedIn, onLogoutAdmin }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-emerald-900/40 bg-emerald-950/95 backdrop-blur-md">
      {/* Top Banner Alert Marquee */}
      <div className="bg-gradient-to-r from-emerald-800 via-amber-700 to-emerald-900 px-4 py-1.5 text-center text-xs font-medium text-white shadow-inner">
        <marquee scrollamount="4" className="block w-full">
          ⚡ Kerala Bumper Pooja & Monsoon Drawings Active! Book your secure physical jackpot ticket now. Online verification portal active within 1 hour. Directorate of Kerala Lotteries proxy bookings. ⚡
        </marquee>
      </div>

      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 md:px-8">
        {/* Kathakali Custom Brand Logo */}
        <div 
          onClick={() => setCurrentPage("home")} 
          className="flex cursor-pointer items-center space-x-3 transition active:scale-95"
          id="brand-logo"
        >
          {/* Detailed Elegant SVG Kathakali Face */}
          <div className="relative h-12 w-12 shrink-0 rounded-full border border-amber-500 bg-gradient-to-b from-emerald-900 to-emerald-950 p-[1px] shadow-md shadow-emerald-950/20">
            <svg
              viewBox="0 0 100 100"
              className="h-full w-full"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Circular Background */}
              <circle cx="50" cy="50" r="46" fill="#1b5e20" />
              <circle cx="50" cy="50" r="41" stroke="#a3e635" strokeWidth="2.5" />
              
              {/* Kathakali Green Face (Vesham) */}
              <path
                d="M50 20C30 20 28 52 30 65C32 78 40 85 50 85C60 85 68 78 70 65C72 52 70 20 50 20Z"
                fill="#4ade80"
              />
              
              {/* Crown/Kireedam bottom details (Gold lines) */}
              <path d="M26 30C35 15 65 15 74 30" stroke="#facc15" strokeWidth="4" />
              <path d="M30 35C40 22 60 22 70 35" stroke="#ffffff" strokeWidth="2" />
              
              {/* Golden forehead tilak/symbol */}
              <path d="M50 22V42" stroke="#ea580c" strokeWidth="6" strokeLinecap="round" />
              <path d="M50 25L42 32H58L50 25Z" fill="#eab308" />
              <circle cx="50" cy="38" r="4" fill="#ffffff" />
              
              {/* Distinctive Kathakali Black Eye Makeup */}
              {/* Left Eye outline and Brow */}
              <path d="M25 46C30 40 45 40 46 48" stroke="#111827" strokeWidth="4.5" strokeLinecap="round" />
              <path d="M28 49C32 46 42 46 43 51" stroke="#111827" strokeWidth="1.5" />
              <circle cx="36" cy="49" r="2.5" fill="#111827" />
              
              {/* Right Eye outline and Brow */}
              <path d="M75 46C70 40 55 40 54 48" stroke="#111827" strokeWidth="4.5" strokeLinecap="round" />
              <path d="M72 49C68 46 58 46 57 51" stroke="#111827" strokeWidth="1.5" />
              <circle cx="64" cy="49" r="2.5" fill="#111827" />

              {/* Red Lips with traditional design */}
              <path
                d="M40 66C44 64 47 67 50 67C53 67 56 64 60 66C56 71 52 71 50 71C48 71 44 71 40 66Z"
                fill="#dc2626"
              />
              <path d="M50 67V71" stroke="#dc2626" strokeWidth="2" />

              {/* White Chutti (facial border paste) framing the face cheeks */}
              <path
                d="M26 40C22 55 24 64 30 72C36 80 44 83 50 83C56 83 64 80 70 72C76 64 78 55 74 40"
                stroke="#ffffff"
                strokeWidth="2.5"
                fill="none"
              />
              <path d="M30 72C34 78 40 82 50 82C60 82 66 78 70 72" stroke="#dc2626" strokeWidth="1" fill="none" />
            </svg>
          </div>

          <div className="flex flex-col">
            <h1 className="text-base font-bold tracking-tight text-white sm:text-lg">
              KERALA <span className="text-emerald-400">LOTTERIES</span>
            </h1>
            <span className="text-[10px] font-semibold tracking-widest text-[#a3e635] uppercase">
              State Mega Jackpot
            </span>
          </div>
        </div>

        {/* Navigation Elements - Desktop */}
        <nav className="hidden items-center space-x-1 md:flex">
          {[
            { id: "home", label: "Home", icon: Info },
            { id: "buy", label: "Buy Ticket", icon: Ticket },
            { id: "result", label: "Check Result", icon: Search },
            { id: "about", label: "About Us", icon: Info },
            { id: "blog", label: "Blog", icon: BookOpen },
            { id: "contact", label: "Contact Us", icon: Mail },
          ].map((tab) => {
            const isActive = currentPage === tab.id;
            return (
              <button
                key={tab.id}
                id={`nav-${tab.id}`}
                onClick={() => setCurrentPage(tab.id)}
                className={`flex items-center space-x-1.5 rounded-lg px-3 py-1.5 text-sm font-medium transition-all duration-200 ${
                  isActive
                    ? "bg-emerald-800 text-white border border-emerald-600/30"
                    : "text-emerald-100 hover:bg-emerald-900/60 hover:text-white"
                }`}
              >
                <tab.icon className={`h-4 w-4 ${isActive ? "text-amber-400" : "text-emerald-400"}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Administration Dashboard Access Controls */}
        <div className="flex items-center space-x-2">
          {isAdminLoggedIn ? (
            <div className="flex items-center space-x-2">
              <span className="hidden rounded-full bg-emerald-800/80 px-2.5 py-1 text-[11px] font-bold tracking-wider text-[#a3e635] uppercase border border-emerald-600/30 md:inline-block">
                ● ADMIN MODE
              </span>
              <button
                _id="logout-btn"
                onClick={() => {
                  onLogoutAdmin();
                  setCurrentPage("home");
                }}
                className="flex items-center space-x-1 rounded-lg bg-red-650 px-3 py-1.5 text-xs font-semibold text-white shadow-md shadow-red-950/20 transition hover:bg-red-600 active:scale-95"
              >
                <span>Logout</span>
              </button>
            </div>
          ) : (
            <button
              id="admin-login-nav"
              onClick={() => setCurrentPage("admin")}
              className={`flex items-center space-x-1 rounded-lg border px-3 py-1.5 text-xs font-bold tracking-wide transition-all duration-200 ${
                currentPage === "admin"
                  ? "bg-amber-500 border-amber-600 text-slate-950"
                  : "border-emerald-700/60 bg-emerald-900/20 text-emerald-300 hover:bg-emerald-900/40 hover:text-white"
              }`}
            >
              <ShieldAlert className="h-3.5 w-3.5" />
              <span>Admin Panel</span>
            </button>
          )}
        </div>
      </div>

      {/* Navigation - Touch Mobile Drawer Panel (Sits compactly below top header) */}
      <div className="border-t border-emerald-900/40 bg-emerald-900/30 md:hidden">
        <div className="flex items-center justify-around overflow-x-auto px-2 py-2">
          {[
            { id: "home", label: "Home", icon: Award },
            { id: "buy", label: "Buy Ticket", icon: Ticket },
            { id: "result", label: "Check Result", icon: Search },
            { id: "about", label: "About", icon: Info },
            { id: "blog", label: "Blog", icon: BookOpen },
            { id: "contact", label: "Contact", icon: Mail },
          ].map((tab) => {
            const isActive = currentPage === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setCurrentPage(tab.id)}
                className={`flex flex-col items-center justify-center rounded-lg px-2 py-1 text-[10px] font-semibold transition-all duration-150 ${
                  isActive ? "text-[#a3e635] scale-105" : "text-emerald-200"
                }`}
              >
                <tab.icon className={`h-4.5 w-4.5 mb-0.5 ${isActive ? "text-amber-450" : "text-emerald-450"}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
}
