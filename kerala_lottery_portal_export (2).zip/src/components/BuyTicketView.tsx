/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { LOTTERY_PACKAGES, INDIAN_STATES } from "../data";
import { CreditCard, QrCode, Upload, ArrowRight, ArrowLeft, CheckCircle2, Loader2, HelpCircle, PhoneCall, Copy, Check, Ticket } from "lucide-react";

interface BuyTicketViewProps {
  selectedPackageId: string | null;
  setSelectedPackageId: (id: string | null) => void;
  setCurrentPage: (page: string) => void;
}

export default function BuyTicketView({ selectedPackageId, setSelectedPackageId, setCurrentPage }: BuyTicketViewProps) {
  const [step, setStep] = React.useState(1); // 1: Package & Details Form, 2: UPI & QR Code Pay, 3: Receipt Upload, 4: Success
  const [loading, setLoading] = React.useState(false);
  const [paymentConfig, setPaymentConfig] = React.useState({ upiId: "keralalotteries@ybl", qrCodeImage: "" });

  // Fields state
  const [pkgId, setPkgId] = React.useState(selectedPackageId || "pkg-3");
  const [name, setName] = React.useState("");
  const [phone, setPhone] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [state, setState] = React.useState("Kerala");
  
  // File state
  const [screenshot, setScreenshot] = React.useState<File | null>(null);
  const [screenshotPreview, setScreenshotPreview] = React.useState<string | null>(null);

  // Assigned Tickets State
  const [assignedTicketNumbers, setAssignedTicketNumbers] = React.useState("");

  // Copy feedbacks
  const [copied, setCopied] = React.useState(false);

  React.useEffect(() => {
    if (selectedPackageId) {
      setPkgId(selectedPackageId);
    }
  }, [selectedPackageId]);

  // Load active UPI credentials from server
  React.useEffect(() => {
    fetch("/api/settings")
      .then((res) => res.json())
      .then((data) => {
        if (data.upiId) {
          setPaymentConfig({ upiId: data.upiId, qrCodeImage: data.qrCodeImage || "" });
        }
      })
      .catch((err) => console.error("Error loading payment structures:", err));
  }, []);

  const activePackage = LOTTERY_PACKAGES.find((p) => p.id === pkgId) || LOTTERY_PACKAGES[2];

  const handleNextStep1 = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !state) {
      alert("Please fill in Name, Phone Number, and select your State.");
      return;
    }
    setStep(2);
  };

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(paymentConfig.upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (!file.type.startsWith("image/")) {
        alert("Please upload valid image files (PNG/JPG/JPEG).");
        return;
      }
      setScreenshot(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setScreenshotPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFormSubmission = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!screenshot) {
      alert("Please upload your payment transaction receipt screenshot.");
      return;
    }

    setLoading(true);
    const formData = new FormData();
    formData.append("name", name.trim());
    formData.append("phone", phone.trim());
    formData.append("email", email.trim());
    formData.append("state", state);
    formData.append("packageName", activePackage.name);
    formData.append("ticketCount", String(activePackage.ticketCount));
    formData.append("amount", String(activePackage.price));
    formData.append("screenshot", screenshot);

    try {
      const response = await fetch("/api/buy", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData?.error || "Booking submission failed.");
      }

      const resData = await response.json();
      const tktNo = resData.ticketNumber || (resData.ticket && resData.ticket.ticketNumber) || "";
      setAssignedTicketNumbers(tktNo);
      setStep(4);
    } catch (error: any) {
      alert(error?.message || "Error submitting verification receipt. Please check your network.");
    } finally {
      setLoading(false);
    }
  };

  // Generate mobile UPI Deep Link to launch standard banking applications
  const getUpiDeepLink = () => {
    const cleanUpi = paymentConfig.upiId.trim();
    const encodedPn = encodeURIComponent("Kerala State Lotteries");
    const amount = activePackage.price;
    return `upi://pay?pa=${cleanUpi}&pn=${encodedPn}&am=${amount}&cu=INR&tn=Kerala%20State%20Lottery%2520Booking`;
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 md:px-8 space-y-12 animate-fade-in" id="buy-ticket-container">
      
      {/* Step Progress Tracker Indicator */}
      <div className="flex items-center justify-center space-x-2 md:space-x-4">
        {[
          { label: "Book Slips", num: 1 },
          { label: "Process Pay", num: 2 },
          { label: "Upload Proof", num: 3 },
          { label: "Complete", num: 4 }
        ].map((pt) => {
          const isActive = step >= pt.num;
          const isCurrent = step === pt.num;
          return (
            <React.Fragment key={pt.num}>
              <div className="flex items-center space-x-1.5">
                <div className={`h-6 w-6 rounded-full flex items-center justify-center text-[11px] font-extrabold border transition-all duration-300 ${
                  isCurrent 
                    ? "bg-[#65a30d] border-[#a3e635] text-white scale-110" 
                    : isActive 
                      ? "bg-emerald-900 border-emerald-600 text-[#a3e635]" 
                      : "bg-emerald-950/20 border-emerald-900 text-emerald-600"
                }`}>
                  {pt.num}
                </div>
                <span className={`text-[10px] sm:text-xs font-bold ${isActive ? "text-white" : "text-emerald-700 font-medium"}`}>{pt.label}</span>
              </div>
              {pt.num < 4 && <div className={`h-[1px] w-4 border-b transition-colors duration-300 ${step > pt.num ? "border-emerald-600" : "border-emerald-900"}`}></div>}
            </React.Fragment>
          );
        })}
      </div>

      {step === 1 && (
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8 items-start">
          
          {/* Form particulars (3 columns) */}
          <div className="md:col-span-3 rounded-2xl border border-emerald-900 bg-emerald-950/40 p-6 shadow-md shrink-0">
            <form onSubmit={handleNextStep1} className="space-y-4 text-xs text-left">
              <h3 className="text-sm font-bold text-white border-b border-emerald-900 pb-2">
                👤 Purchaser Demographics Form
              </h3>

              <div className="space-y-1 bg-[#022c22]/30 p-3 rounded-lg border border-emerald-900/40 mb-2">
                <label className="text-emerald-450 font-bold block mb-1">SELECTED VALUE PACKAGE</label>
                <select 
                  value={pkgId}
                  onChange={(e) => setPkgId(e.target.value)}
                  className="w-full bg-[#021f18] text-white border border-emerald-800 rounded px-2.5 py-1.5 focus:outline-none"
                >
                  {LOTTERY_PACKAGES.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.ticketCount} slips) - Rs. {p.price}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-emerald-300 font-semibold block">Full Name <span className="text-red-500">*</span></label>
                <input 
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full rounded-lg border border-emerald-800/60 bg-emerald-955 px-3 py-2 text-white placeholder-emerald-800 focus:outline-none focus:border-emerald-500 h-9"
                  placeholder="e.g. Ramesh Krishnan"
                />
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-1">
                  <label className="text-emerald-300 font-semibold block">WhatsApp number <span className="text-red-500">*</span></label>
                  <input 
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full rounded-lg border border-emerald-800/60 bg-emerald-955 px-3 py-2 text-white placeholder-emerald-800 focus:outline-none focus:border-emerald-500 h-9"
                    placeholder="e.g. 94460 12345"
                  />
                  <span className="text-[10px] text-emerald-450 italic">Important for fetching results!</span>
                </div>
                <div className="space-y-1">
                  <label className="text-emerald-300 font-semibold block">Email address (Optional)</label>
                  <input 
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full rounded-lg border border-emerald-800/60 bg-emerald-955 px-3 py-2 text-white placeholder-emerald-800 focus:outline-none focus:border-emerald-500 h-9"
                    placeholder="e.g. ramesh@gmail.com"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-emerald-300 font-semibold block">State of domicile <span className="text-red-500">*</span></label>
                <select 
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="w-full rounded-lg border border-emerald-800/60 bg-emerald-955 px-3 py-2 text-white focus:outline-none focus:border-emerald-500 h-10 select-theme"
                >
                  {INDIAN_STATES.map((st) => (
                    <option key={st} value={st}>{st}</option>
                  ))}
                </select>
              </div>

              <button
                type="submit"
                className="w-full flex items-center justify-center space-x-1 py-3 bg-amber-500 hover:bg-[#b58c07] active:scale-95 text-slate-950 rounded-xl text-xs font-bold transition shadow-md shadow-amber-950/20"
              >
                <span>PROCEED TO SECURE CHECKOUT</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </form>
          </div>

          {/* Pricing Summary (2 columns) */}
          <div className="md:col-span-2 space-y-4 text-left">
            <div className="rounded-2xl border border-emerald-900 bg-emerald-950/30 p-6 space-y-4">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider border-b border-emerald-900 pb-1.5">
                🛒 Booking Invoice Summary
              </h3>
              
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-emerald-300 font-medium">Selected Package:</span>
                  <span className="text-white font-bold">{activePackage.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-emerald-300 font-medium">Ticket Volume:</span>
                  <span className="text-[#a3e635] font-bold">{activePackage.ticketCount} Slips</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-emerald-300 font-medium">Service & Delivery Fee:</span>
                  <span className="text-emerald-400">Rs. 0.00 (Free)</span>
                </div>
                <div className="border-t border-emerald-900/40 my-3"></div>
                <div className="flex justify-between items-baseline pt-1">
                  <span className="text-xs text-white font-bold">Total Payable:</span>
                  <span className="text-xl font-black text-amber-500">Rs. {activePackage.price}</span>
                </div>
              </div>

              <div className="rounded p-3 bg-emerald-950/80 border border-emerald-900 text-[10px] text-emerald-450 leading-relaxed space-y-1">
                <p className="font-semibold text-white">📋 Proxy Delivery Terms:</p>
                <p>Upon payment verification, we dispatch physical agents to legal stalls in Trivandrum to purchase official paper lotteries. Ticket codes are uploaded to your Phone Number registry within 1 hour.</p>
              </div>
            </div>
          </div>

        </div>
      )}

      {step === 2 && (
        <div className="mx-auto max-w-2xl rounded-2xl border border-emerald-900 bg-emerald-950/40 p-6 md:p-8 space-y-6 shadow-md text-center">
          <div className="space-y-1">
            <h3 className="text-md font-bold text-white">💰 Secure UPI Payment Gateway</h3>
            <p className="text-xs text-emerald-300 leading-relaxed font-normal">
              Scan our official QR Code below or transfer Rs. <strong className="text-amber-550">{activePackage.price}</strong> directly to our verified administrative UPI ID handle.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            
            {/* Left QR Panel */}
            <div className="bg-emerald-950/60 p-5 rounded-2xl border border-emerald-900 flex flex-col items-center justify-center space-y-3">
              <span className="text-[10px] uppercase font-bold text-emerald-300 tracking-wider">OFFICIAL MERCHANT QR CODE</span>
              
              <div className="relative h-44 w-44 bg-white rounded-lg p-2.5 flex items-center justify-center border-2 border-[#16a34a] overflow-hidden shadow">
                {paymentConfig.qrCodeImage ? (
                  <img 
                    src={paymentConfig.qrCodeImage} 
                    alt="Kerala state lotteries standard payment qr code image" 
                    className="h-full w-full object-contain"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  // Elegant vector fallback representing QR Code frame
                  <div className="flex flex-col items-center justify-center space-y-2 h-full w-full text-slate-800">
                    <QrCode className="h-16 w-16 text-emerald-800 animate-pulse" strokeWidth={1.5} />
                    <span className="text-[9px] font-bold text-slate-600">Scan code on screen</span>
                  </div>
                )}
              </div>
              <p className="text-[9px] text-emerald-450">Amounts match auto pre-filled correctly on mobile apps.</p>
            </div>

            {/* Right UPI ID Panel */}
            <div className="space-y-4 text-left text-xs text-emerald-250 leading-relaxed">
              <div className="space-y-1.5 bg-[#022c22] rounded-xl border border-emerald-900 p-4 relative">
                <p className="text-emerald-450 font-semibold text-[9px] uppercase tracking-wider block">Admin Merchant UPI ID Handle</p>
                <div className="flex items-center justify-between mt-1">
                  <span className="font-mono text-xs font-semibold text-white tracking-wide">{paymentConfig.upiId}</span>
                  <button 
                    onClick={handleCopyUpi} 
                    className="flex h-7 w-7 items-center justify-center rounded border border-emerald-800 hover:bg-emerald-900 text-emerald-300 transition"
                  >
                    {copied ? <Check className="h-3.5 w-3.5 text-lime-500" /> : <Copy className="h-3.5 w-3.5" />}
                  </button>
                </div>
                {copied && <p className="absolute -bottom-3.5 right-4 text-[9px] font-extrabold text-lime-550 animate-scale-up uppercase">COPIED SUCCESSFULLY!</p>}
              </div>

              {/* UPI Intents Mobile Redirect details */}
              <div className="space-y-3 pt-2">
                <p className="text-[11px] leading-normal text-emerald-300">
                  📲 <strong>Prefer to pay on phone?</strong> Tap the button below to automatically launch Google Pay, PhonePe, Paytm, or BHIM with pre-configured invoice amounts.
                </p>
                
                {/* Mobile UPI launcher anchor */}
                <a
                  href={getUpiDeepLink()}
                  onClick={(e) => {
                    // Log to make sure the flow operates correctly
                    console.log("UPI launch event intent click:", getUpiDeepLink());
                  }}
                  className="w-full flex items-center justify-center space-x-2 py-3 bg-[#65a30d] hover:bg-[#4d7c0f] text-white font-bold rounded-xl text-center active:scale-95 transition shadow shadow-lime-950/20"
                >
                  <CreditCard className="h-4.5 w-4.5" />
                  <span>PAY VIA MOBILE UPI APP</span>
                </a>
              </div>

            </div>

          </div>

          <div className="border-t border-emerald-900/40 pt-4 flex items-center justify-between">
            <button 
              onClick={() => setStep(1)}
              className="inline-flex items-center space-x-1 text-xs text-emerald-400 hover:text-white transition"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              <span>Go Back</span>
            </button>
            <button 
              onClick={() => setStep(3)}
              className="inline-flex items-center space-x-1.5 rounded-lg bg-amber-500 active:scale-95 text-slate-950 font-bold text-xs px-5 py-2.5 hover:bg-[#b58c07] transition"
            >
              <span>I Have Paid, Upload Screen</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

        </div>
      )}

      {step === 3 && (
        <div className="mx-auto max-w-xl rounded-2xl border border-emerald-900 bg-emerald-950/40 p-6 md:p-8 space-y-6 shadow-md text-center">
          <div className="space-y-1">
            <h3 className="text-md font-bold text-white">📤 Submit Transaction Proof Screenshot</h3>
            <p className="text-xs text-emerald-300 leading-relaxed font-normal">
              To expedite ticket assignments, please upload a clear, legible screenshot of your UPI transfer confirmation page displaying the transfer transaction reference ID.
            </p>
          </div>

          <form onSubmit={handleFormSubmission} className="space-y-6">
            
            {/* Visual Screen Drag File Input Dropzone */}
            <div className="rounded-xl border border-dashed border-emerald-850 bg-[#021f18] hover:bg-[#022c22]/50 cursor-pointer p-6 relative transition">
              <input 
                type="file"
                required
                accept="image/*"
                onChange={handleFileChange}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
              
              {screenshotPreview ? (
                <div className="space-y-3">
                  <img 
                    src={screenshotPreview} 
                    alt="Receipt screen visual upload check preview" 
                    className="h-40 mx-auto object-contain rounded border border-emerald-800 p-1 bg-white"
                  />
                  <div className="text-[11px] text-[#a3e635] font-semibold">
                    📂 Selected: {screenshot?.name}
                  </div>
                  <span className="text-[9px] text-emerald-405 block">(Click or drag elements to replace photo)</span>
                </div>
              ) : (
                <div className="space-y-2 py-4 flex flex-col items-center">
                  <Upload className="h-10 w-10 text-emerald-500 animate-bounce" />
                  <p className="text-xs text-white font-extrabold font-sans">Click or Drag & Drop screenshot photo here</p>
                  <p className="text-[10px] text-emerald-450">Accepts JPEG, PNG, or WebP up to 5MB</p>
                </div>
              )}
            </div>

            {loading ? (
              <div className="flex items-center justify-center space-x-2 py-3 text-emerald-300 text-xs">
                <Loader2 className="h-5 w-5 animate-spin text-[#a3e635]" />
                <span>Transmitting payload to live registry servers...</span>
              </div>
            ) : (
              <button
                type="submit"
                className="w-full flex items-center justify-center space-x-1 py-3 bg-amber-500 hover:bg-[#b58c07] active:scale-95 text-slate-950 rounded-xl text-xs font-bold transition shadow-md shadow-amber-950/20"
              >
                <span>SUBMIT VERIFICATION RECEIPT</span>
              </button>
            )}

          </form>

          <button 
            disabled={loading}
            onClick={() => setStep(2)}
            className="inline-flex items-center space-x-1 text-xs text-emerald-400 hover:text-white transition active:scale-95"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            <span>Go Back to payment</span>
          </button>
        </div>
      )}

      {step === 4 && (
        <div className="mx-auto max-w-xl rounded-2xl border border-[#16a34a] bg-[#022c22]/85 p-8 text-center space-y-6 shadow-xl relative overflow-hidden animate-scale-up">
          
          <div className="absolute top-0 right-0 h-24 w-24 bg-gradient-to-br from-lime-500/10 to-transparent rounded-bl-full"></div>

          <div className="flex flex-col items-center justify-center space-y-3">
            <CheckCircle2 className="h-16 w-16 text-[#a3e635] animate-pulse" />
            <h2 className="text-xl font-bold text-white uppercase tracking-tight">Booking Request Dispatched!</h2>
            <p className="text-[#a3e635] font-extrabold text-[11px] uppercase tracking-wider">
              🧾 INVOICE VERIFICATION ACTIVE
            </p>
          </div>

          {assignedTicketNumbers && (
            <div className="space-y-3 bg-[#011410] rounded-xl py-4 px-4 border border-emerald-900 shadow-inner relative text-left">
              {/* Ticket physical serrated-looking side circles */}
              <div className="absolute left-[-6px] top-1/2 -translate-y-1/2 w-3 h-3 bg-[#022c22] rounded-full border-r border-[#16a34a]/30"></div>
              <div className="absolute right-[-6px] top-1/2 -translate-y-1/2 w-3 h-3 bg-[#022c22] rounded-full border-l border-[#16a34a]/30"></div>

              <div className="flex items-center space-x-1.5 pb-1.5 border-b border-emerald-900/40">
                <Ticket className="h-4.5 w-4.5 text-[#a3e635] shrink-0" />
                <span className="text-[10px] font-bold text-[#a3e635] uppercase tracking-wider">INSTANTLY ASSIGNED SLIPS ({assignedTicketNumbers.split(",").length})</span>
              </div>

              <p className="text-[9px] text-emerald-400">These official coupon numbers have been reserved and assigned to your phone number instantly:</p>
              
              <div className="flex flex-wrap gap-1.5 pt-1">
                {assignedTicketNumbers.split(",").map((num, i) => (
                  <span key={i} className="font-mono text-[11px] font-extrabold text-[#a3e635] bg-[#022c22] border border-emerald-800/80 px-2.5 py-1 rounded inline-block shadow">
                    🎟️ {num.trim()}
                  </span>
                ))}
              </div>
            </div>
          )}

          <div className="rounded-xl bg-[#021c16] border border-emerald-900/60 p-5 space-y-4 text-left text-xs leading-normal">
            <p className="text-emerald-200">
              <strong>Dear {name},</strong> your payment verification inquiry has been securely cataloged inside registry table indexes under telephone identifier <strong>{phone}</strong>.
            </p>
            <div className="border-t border-emerald-900/40 my-2"></div>
            <div className="space-y-2 text-[11px] text-emerald-300">
              <p>📍 <strong>Verification ETA:</strong> Our Palayam finance staff will verify your screenshot against live merchant bank statement APIs within <strong>5 to 15 minutes</strong>.</p>
              <p>🎫 <strong>Ticket Allocation:</strong> Once verified, official paper-slips will be purchased and serial codes uploaded instantly. You can query numbers using the checking widget with your phone identifier!</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={() => {
                // Clear state
                setName("");
                setPhone("");
                setEmail("");
                setScreenshot(null);
                setScreenshotPreview(null);
                setStep(1);
                setCurrentPage("result");
              }}
              className="w-full sm:w-auto flex items-center justify-center space-x-1 px-5 py-2.5 rounded-lg bg-amber-500 text-slate-950 text-xs font-bold hover:bg-[#b58c07] transition"
            >
              <span>GO CHECK RESULTS REGISTRY</span>
            </button>
            <button
              onClick={() => {
                setName("");
                setPhone("");
                setEmail("");
                setScreenshot(null);
                setScreenshotPreview(null);
                setStep(1);
                setCurrentPage("home");
              }}
              className="w-full sm:w-auto text-xs font-semibold hover:text-white text-emerald-300 hover:underline"
            >
              Return to Homepage
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
