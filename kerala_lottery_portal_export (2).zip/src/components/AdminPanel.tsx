/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { TicketPurchase } from "../types";
import { ShieldAlert, LogIn, Loader2, CheckCircle2, XCircle, Trash2, Edit2, Settings, ListFilter, Image, Save, Key, RefreshCw, MessageSquare, Download } from "lucide-react";

interface AdminPanelProps {
  passcode: string | null;
  setPasscode: (passcode: string | null) => void;
  isAdminLoggedIn: boolean;
  setIsAdminLoggedIn: (val: boolean) => void;
}

export default function AdminPanel({ passcode, setPasscode, isAdminLoggedIn, setIsAdminLoggedIn }: AdminPanelProps) {
  const [loginCode, setLoginCode] = React.useState("");
  const [localLoading, setLocalLoading] = React.useState(false);
  const [errorMsg, setErrorMsg] = React.useState<string | null>(null);

  // Dashboard contents state
  const [bookings, setBookings] = React.useState<TicketPurchase[]>([]);
  const [dbStatus, setDbStatus] = React.useState<any>({});
  const [fetchingBookings, setFetchingBookings] = React.useState(false);
  
  // Tab control
  const [currentTab, setCurrentTab] = React.useState<"bookings" | "settings">("bookings");

  // Selection state for verifying modal
  const [editingBooking, setEditingBooking] = React.useState<TicketPurchase | null>(null);
  const [assignedSerials, setAssignedSerials] = React.useState("");
  const [winningPrizeState, setWinningPrizeState] = React.useState("Result Pending");
  const [isWinner, setIsWinner] = React.useState(false);
  const [winningTicket, setWinningTicket] = React.useState("");
  const [winningPrizePreset, setWinningPrizePreset] = React.useState("");

  // Manual Offline Registration states
  const [isAddingManual, setIsAddingManual] = React.useState(false);
  const [manualName, setManualName] = React.useState("");
  const [manualPhone, setManualPhone] = React.useState("");
  const [manualEmail, setManualEmail] = React.useState("");
  const [manualState, setManualState] = React.useState("Kerala");
  const [manualPackageName, setManualPackageName] = React.useState("Single Bumper Ticket");
  const [manualTicketCount, setManualTicketCount] = React.useState("1");
  const [manualAmount, setManualAmount] = React.useState("40");
  const [manualTicketNumber, setManualTicketNumber] = React.useState("");
  const [manualWinningPrize, setManualWinningPrize] = React.useState("Result Pending");

  // Settings Fields State
  const [upiIdSetting, setUpiIdSetting] = React.useState("");
  const [qrCodeBase64, setQrCodeBase64] = React.useState("");
  const [contactNumberSetting, setContactNumberSetting] = React.useState("");
  const [contactEmailSetting, setContactEmailSetting] = React.useState("");
  const [whatsappNumberSetting, setWhatsappNumberSetting] = React.useState("");
  const [updatingSettings, setUpdatingSettings] = React.useState(false);

  // Change passcode fields
  const [currentSecCode, setCurrentSecCode] = React.useState("");
  const [newSecCode, setNewSecCode] = React.useState("");

  React.useEffect(() => {
    if (isAdminLoggedIn && passcode) {
      loadDashboardData();
    }
  }, [isAdminLoggedIn, passcode]);

  const loadDashboardData = async () => {
    if (!passcode) return;
    setFetchingBookings(true);
    try {
      // 1. Load bookings
      const bookRes = await fetch(`/api/admin/bookings?passcode=${encodeURIComponent(passcode)}`);
      if (!bookRes.ok) throw new Error("Unverified administrator session expired.");
      const bookData = await bookRes.json();
      setBookings(bookData);

      // 2. Load system status
      const statRes = await fetch("/api/status");
      if (statRes.ok) {
        const statData = await statRes.json();
        setDbStatus(statData);
      }

      // 3. Load active settings
      const setRes = await fetch("/api/settings");
      if (setRes.ok) {
        const setData = await setRes.json();
        setUpiIdSetting(setData.upiId || "keralalotteries@ybl");
        setQrCodeBase64(setData.qrCodeImage || "");
        setContactNumberSetting(setData.contactNumber || "+91 94460 01234");
        setContactEmailSetting(setData.contactEmail || "contact@keralalottery.com");
        setWhatsappNumberSetting(setData.whatsappNumber || "+91 94460 01234");
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err?.message || "Error reading dashboard nodes.");
    } finally {
      setFetchingBookings(false);
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginCode.trim()) return;

    setLocalLoading(true);
    setErrorMsg(null);

    try {
      const response = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ passcode: loginCode.trim() }),
      });

      if (!response.ok) {
        throw new Error("Incorrect passcode. Try again.");
      }

      const data = await response.json();
      if (data.authenticated) {
        setPasscode(loginCode.trim());
        setIsAdminLoggedIn(true);
      }
    } catch (err: any) {
      setErrorMsg(err?.message || "Authentication attempt failed.");
    } finally {
      setLocalLoading(false);
    }
  };

  const handleVerifySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBooking || !passcode) return;

    setLocalLoading(true);
    try {
      const response = await fetch("/api/admin/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          bookingId: editingBooking.id,
          ticketNumber: assignedSerials.trim(),
          winningPrize: winningPrizeState.trim(),
          passcode: passcode
        }),
      });

      if (!response.ok) throw new Error("Verification dispatch rejected.");
      
      setEditingBooking(null);
      loadDashboardData();
    } catch (err: any) {
      alert(err?.message || "Verification transaction failed.");
    } finally {
      setLocalLoading(false);
    }
  };

  const handleRejectClick = async (id: number) => {
    if (!confirm("Are you sure you want to REJECT this purchase booking? This will cancel ticket codes allocation.") || !passcode) return;

    try {
      const response = await fetch("/api/admin/reject", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bookingId: id, passcode: passcode }),
      });

      if (!response.ok) throw new Error("Reject request failed.");
      loadDashboardData();
    } catch (err: any) {
      alert(err?.message || "Failed to issue reject command.");
    }
  };

  const handleDeleteClick = async (id: number) => {
    if (!confirm("WARNING: Deleting bookings destroys associated files and ledger references permanently. Proceed?") || !passcode) return;

    try {
      const response = await fetch("/api/admin/delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bookingId: id, passcode: passcode }),
      });

      if (!response.ok) throw new Error("Delete transaction rejected by API.");
      loadDashboardData();
    } catch (err: any) {
      alert(err?.message || "Deletion request failed.");
    }
  };

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!passcode) return;

    setLocalLoading(true);
    try {
      const resp = await fetch("/api/admin/add-manual", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          passcode,
          name: manualName,
          phone: manualPhone,
          email: manualEmail,
          state: manualState,
          packageName: manualPackageName,
          ticketCount: Number(manualTicketCount),
          amount: Number(manualAmount),
          ticketNumber: manualTicketNumber.trim(),
          winningPrize: manualWinningPrize.trim()
        })
      });

      if (!resp.ok) {
        const err = await resp.json();
        throw new Error(err.error || "Failed to add manual customer ticket");
      }

      alert("Offline customer ticket added and verified successfully!");
      setIsAddingManual(false);
      // Reset fields
      setManualName("");
      setManualPhone("");
      setManualEmail("");
      setManualState("Kerala");
      setManualPackageName("Single Bumper Ticket");
      setManualTicketCount("1");
      setManualAmount("40");
      setManualTicketNumber("");
      setManualWinningPrize("Result Pending");
      
      loadDashboardData();
    } catch (err: any) {
      alert(err.message || "An error occurred");
    } finally {
      setLocalLoading(false);
    }
  };

  const handleOpenVerifyModal = (item: TicketPurchase) => {
    setEditingBooking(item);
    setAssignedSerials(item.ticketNumber || "");
    const prize = item.winningPrize || "Result Pending";
    setWinningPrizeState(prize);
    
    const isW = prize !== "Result Pending" && prize !== "" && !prize.toLowerCase().includes("pending") && !prize.toLowerCase().includes("fail");
    setIsWinner(isW);

    const tickets = (item.ticketNumber || "").split(",").map(t => t.trim()).filter(Boolean);
    setWinningTicket(tickets[0] || "All Tickets");
    setWinningPrizePreset("");
  };

  // Convert uploaded settings image file to base64 string
  const handleQrUploadLocal = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setQrCodeBase64(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!passcode) return;

    setUpdatingSettings(true);
    try {
      const response = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          upiId: upiIdSetting.trim(),
          qrCodeImage: qrCodeBase64,
          contactNumber: contactNumberSetting.trim(),
          contactEmail: contactEmailSetting.trim(),
          whatsappNumber: whatsappNumberSetting.trim(),
          passcode: passcode
        }),
      });

      if (!response.ok) throw new Error("Settings modification rejected.");
      alert("Portal administration and gateway settings successfully updated!");
      loadDashboardData();
    } catch (err: any) {
      alert(err?.message || "Failed to update gateway settings.");
    } finally {
      setUpdatingSettings(false);
    }
  };

  const handleChangePasscode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentSecCode || !newSecCode) return;

    try {
      const response = await fetch("/api/settings/passcode", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          currentPasscode: currentSecCode.trim(),
          newPasscode: newSecCode.trim()
        }),
      });

      if (!response.ok) {
        throw new Error("Current passcode matches incorrectly.");
      }

      setPasscode(newSecCode.trim());
      setCurrentSecCode("");
      setNewSecCode("");
      alert("Administrative passcode successfully updated in database! Use this new code next time.");
    } catch (err: any) {
      alert(err?.message || "Passcode update task failed.");
    }
  };

  // Login visual overlay screen
  if (!isAdminLoggedIn) {
    return (
      <div className="mx-auto max-w-md px-4 py-20 animate-fade-in" id="admin-login-panel">
        <div className="rounded-2xl border border-emerald-900 bg-emerald-950/40 p-8 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 h-16 w-16 bg-gradient-to-br from-amber-500/10 to-transparent rounded-bl-full"></div>

          <div className="text-center space-y-2 mb-6">
            <ShieldAlert className="h-12 w-12 text-amber-500 mx-auto" strokeWidth={1.5} />
            <h1 className="text-xl font-bold text-white uppercase tracking-tight">Administrative Lockbox</h1>
            <p className="text-[11px] text-emerald-300">Authorize administrative sessions to manage ticket transactions, verify payment screenshots, and update checkout settings.</p>
          </div>

          <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs text-left">
            <div className="space-y-1">
              <label className="text-emerald-300 font-bold">Administration Code</label>
              <input 
                type="password"
                required
                value={loginCode}
                onChange={(e) => setLoginCode(e.target.value)}
                autoFocus
                className="w-full text-center h-10 tracking-[0.25em] rounded-lg border border-emerald-800/80 bg-[#021c16] text-white focus:outline-none focus:border-emerald-500 text-sm font-black"
                placeholder="••••••••"
              />
            </div>

            {errorMsg && (
              <p className="rounded bg-red-950/30 p-2 text-[11px] text-red-400 font-semibold border border-red-900/40">
                ⚠ {errorMsg}
              </p>
            )}

            <button
              type="submit"
              disabled={localLoading}
              className="w-full flex items-center justify-center space-x-1.5 py-2.5 bg-[#a3e635] hover:bg-lime-500 text-slate-950 rounded-lg text-xs font-extrabold active:scale-95 disabled:opacity-50 transition shadow-md shadow-emerald-950/20"
            >
              {localLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  <LogIn className="h-4 w-4" />
                  <span>AUTHORIZE ACCESS</span>
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Loaded Counts
  const totalInquiries = bookings.length;
  const pendingInquiries = bookings.filter((t) => t.status === "pending").length;
  const verifiedInquiries = bookings.filter((t) => t.status === "verified").length;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 md:px-8 space-y-8 animate-fade-in" id="admin-main-dashboard">
      
      {/* Top Welcome and Server Info Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-emerald-900/60 pb-4">
        <div className="text-left space-y-1">
          <h1 className="text-2xl font-black text-white uppercase tracking-tight">
            🛡️ Administrative Desk <span className="text-emerald-450">Settings</span>
          </h1>
          <p className="text-xs text-emerald-350">
            Active Container Node: <strong className="text-amber-500">{dbStatus.activeDB || "Scanning..."}</strong>
          </p>
        </div>

        {/* Action Toggle Tabs */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setCurrentTab("bookings")}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-bold tracking-wide transition ${
              currentTab === "bookings" 
                ? "bg-emerald-800 text-white border border-emerald-600/30" 
                : "bg-emerald-950/40 border border-emerald-950 text-emerald-300 hover:text-white"
            }`}
          >
            <ListFilter className="h-3.5 w-3.5" />
            <span>Manage Bookings ({totalInquiries})</span>
          </button>
          
          <button
            onClick={() => setCurrentTab("settings")}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-bold tracking-wide transition ${
              currentTab === "settings" 
                ? "bg-emerald-800 text-white border border-emerald-600/30" 
                : "bg-emerald-950/40 border border-emerald-950 text-emerald-300 hover:text-white"
            }`}
          >
            <Settings className="h-3.5 w-3.5" />
            <span>Setup Gateway UI</span>
          </button>

          <button
            onClick={() => {
              setCurrentTab("bookings");
              setIsAddingManual(true);
            }}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-black tracking-wide bg-amber-500 hover:bg-amber-400 text-slate-950 transition active:scale-95 shadow cursor-pointer"
          >
            <span>➕ Add Offline Customer</span>
          </button>

          <button 
            onClick={loadDashboardData}
            title="Refresh database entries"
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-emerald-800 text-emerald-300 hover:bg-emerald-900 transition"
          >
            {fetchingBookings ? <Loader2 className="h-4 w-4 animate-spin text-[#a3e635]" /> : <RefreshCw className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {currentTab === "bookings" && (
        <div className="space-y-6">
          
          {/* Summary Scoreboard Cards */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            {[
              { label: "Total Purchased inquiries", count: totalInquiries, color: "from-emerald-900/40 to-emerald-950/40" },
              { label: "Awaiting Screenshot Verification", count: pendingInquiries, color: "from-amber-950/30 to-emerald-950/40", highlight: pendingInquiries > 0 ? "text-amber-500 animate-pulse font-extrabold" : "text-emerald-400" },
              { label: "Verified Claims Handed Over", count: verifiedInquiries, color: "from-emerald-900/80 to-[#022c22]" }
            ].map((card, i) => (
              <div key={i} className={`rounded-2xl border border-emerald-900 bg-gradient-to-r p-5 flex items-center justify-between shadow ${card.color}`}>
                <span className="text-xs font-semibold text-emerald-300 md:max-w-[70%] text-left block leading-relaxed">{card.label}</span>
                <span className={`text-3xl font-black ${card.highlight || "text-white"}`}>{card.count}</span>
              </div>
            ))}
          </div>

          {/* Bookings Table list layout */}
          <div className="rounded-2xl border border-emerald-900 bg-emerald-950/20 overflow-hidden shadow">
            {fetchingBookings && bookings.length === 0 ? (
              <div className="p-12 text-center text-xs text-emerald-300">
                <Loader2 className="h-6 w-6 animate-spin text-[#a3e635] mx-auto mb-2" />
                <span>Reading bookings registry...</span>
              </div>
            ) : bookings.length === 0 ? (
              <div className="p-12 text-center text-xs text-emerald-300 space-y-2">
                <p className="font-bold text-white uppercase text-sm">No bookings entries recorded</p>
                <p>Buy tickes on the website as safety checks first, then return here.</p>
              </div>
            ) : (
              <div className="overflow-x-auto w-full">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-emerald-950 text-emerald-300 border-b border-emerald-900 text-[10px] font-bold uppercase tracking-wider">
                      <th className="px-6 py-4">Demographics</th>
                      <th className="px-6 py-4">Option Pack</th>
                      <th className="px-6 py-4">Verification Screenshot</th>
                      <th className="px-6 py-4">Ledger Status</th>
                      <th className="px-6 py-4">Serials / Prizes</th>
                      <th className="px-6 py-4 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-emerald-950/60 leading-normal">
                    {bookings.map((item) => (
                      <tr key={item.id} className="hover:bg-emerald-900/10 transition">
                        {/* Demographic details */}
                        <td className="px-6 py-4 space-y-1">
                          <p className="font-bold text-white text-sm">{item.name}</p>
                          <p className="text-[11px] text-emerald-300 font-mono">{item.phone}</p>
                          <p className="text-[10px] text-emerald-450">{item.state} • {item.email || "No email"}</p>
                        </td>

                        {/* Optional packages info */}
                        <td className="px-6 py-4 space-y-1 text-xs">
                          <p className="font-bold text-white">{item.packageName}</p>
                          <p className="text-amber-500 font-bold font-mono text-[11px]">Rs. {item.amount}</p>
                          <p className="text-[10px] text-emerald-400">Qty: {item.ticketCount} slips</p>
                        </td>

                        {/* Screenshot image validation thumb */}
                        <td className="px-6 py-4">
                          <a 
                            href={item.screenshotPath} 
                            target="_blank" 
                            rel="noreferrer"
                            className="inline-flex items-center space-x-1 border border-emerald-800 hover:border-emerald-500 rounded bg-[#021f18] p-1.5 transition text-[#a3e635] font-bold text-[10px]"
                          >
                            <Image className="h-3.5 w-3.5 shrink-0" />
                            <span>Zoom Screenshot Receipt</span>
                          </a>
                        </td>

                        {/* Ledger verified metrics status */}
                        <td className="px-6 py-4">
                          {item.status === "pending" && (
                            <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded bg-amber-950/60 text-amber-500 text-[10px] font-bold border border-amber-900/60 uppercase tracking-wide">
                              Awaiting Verification
                            </span>
                          )}
                          {item.status === "rejected" && (
                            <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded bg-red-950/60 text-red-400 text-[10px] font-bold border border-red-900/60 uppercase tracking-wide">
                              Cancelled / Rejected
                            </span>
                          )}
                          {item.status === "verified" && (
                            <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded bg-emerald-950/60 text-[#a3e635] text-[10px] font-bold border border-emerald-800/60 uppercase tracking-wide">
                              Cleared
                            </span>
                          )}
                        </td>

                        {/* Assigned Serials and winning tags */}
                        <td className="px-6 py-4 space-y-1">
                          {item.status === "verified" ? (
                            <div className="space-y-1">
                              <p className="font-mono text-[11px] font-semibold text-white tracking-wider max-w-[150px] truncate uppercase bg-[#022c22] border border-emerald-850 rounded px-1.5 py-0.5">
                                🎫 {item.ticketNumber}
                              </p>
                              <p className="text-[10px] font-bold text-amber-500 uppercase">
                                🏆 {item.winningPrize || "Result Pending"}
                              </p>
                            </div>
                          ) : (
                            <span className="text-[10px] text-emerald-450 italic">Serials not allocated</span>
                          )}
                        </td>

                        {/* Dynamic triggers action pane */}
                        <td className="px-6 py-4 text-center">
                          <div className="flex items-center justify-center space-x-2">
                            {item.status === "pending" ? (
                              <>
                                <button
                                  onClick={() => handleOpenVerifyModal(item)}
                                  className="flex items-center space-x-1 rounded bg-[#a3e635] hover:bg-lime-500 text-slate-950 px-2.5 py-1 text-[11px] font-extrabold shadow transition active:scale-95 cursor-pointer"
                                >
                                  <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
                                  <span>Verify & Issue</span>
                                </button>
                                <button
                                  onClick={() => handleRejectClick(item.id)}
                                  className="flex items-center justify-center rounded bg-red-950 hover:bg-red-900 border border-red-900 text-red-500 p-1.5 transition active:scale-95"
                                  title="Reject Booking"
                                >
                                  <XCircle className="h-3.5 w-3.5" />
                                </button>
                              </>
                            ) : (
                              <button
                                onClick={() => handleOpenVerifyModal(item)}
                                className="flex items-center space-x-1 rounded bg-emerald-900/40 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 px-2.5 py-1 text-[11px] font-semibold transition active:scale-95 cursor-pointer"
                              >
                                <Edit2 className="h-3 w-3" />
                                <span>Edit Serials</span>
                              </button>
                            )}

                            {/* Standard message click route */}
                            <a 
                              href={`https://wa.me/${item.phone.replace(/[^0-9]/g, "")}`}
                              target="_blank"
                              rel="noreferrer"
                              title="Chat with buyer on Whatspp"
                              className="flex items-center justify-center rounded border border-emerald-800 hover:bg-emerald-900 text-emerald-400 p-1.5 transition active:scale-95"
                            >
                              <MessageSquare className="h-3.5 w-3.5" />
                            </a>

                            <button
                              onClick={() => handleDeleteClick(item.id)}
                              className="flex items-center justify-center rounded border border-red-900 hover:bg-red-950/40 text-red-400 p-1.5 transition active:scale-95"
                              title="Delete Bookings"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </td>

                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

        </div>
      )}

      {currentTab === "settings" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left">
          
          {/* Checkout gateway parameters modifier */}
          <div className="rounded-2xl border border-emerald-900 bg-emerald-950/40 p-6 md:p-8 space-y-6 shadow-md shrink-0">
            <h3 className="text-sm font-bold text-white uppercase border-b border-emerald-900 pb-2 flex items-center space-x-1.5">
              <Settings className="h-4.5 w-4.5 text-amber-500" />
              <span>Modify Checkout payment Gateway</span>
            </h3>

            <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
              
              <div className="space-y-1">
                <label className="text-emerald-300 font-bold">Dynamic Admin UPI ID Handle</label>
                <input 
                  type="text"
                  required
                  value={upiIdSetting}
                  onChange={(e) => setUpiIdSetting(e.target.value)}
                  className="w-full rounded-lg border border-emerald-800 bg-[#021c16] px-3 py-2 text-white placeholder-emerald-850 focus:outline-none focus:border-emerald-500 h-9"
                  placeholder="e.g. keralalotteries@ybl"
                />
                <span className="text-[10px] text-emerald-450 italic mt-0.5">This UPI is loaded automatically across checkout portals for all client purchases!</span>
              </div>

              {/* QR Code base64 image generator */}
              <div className="space-y-2">
                <label className="text-emerald-300 font-bold block">Dynamic QR Code Image</label>
                
                {qrCodeBase64 && (
                  <div className="p-3 border border-emerald-900 rounded bg-emerald-955 flex items-center justify-between">
                    <span className="text-[#a3e635] font-bold text-[10px]">📁 Active Custom QR code loaded</span>
                    <button 
                      type="button" 
                      onClick={() => setQrCodeBase64("")}
                      className="text-red-400 hover:underline text-[10px] uppercase font-bold"
                    >
                      Delete Code
                    </button>
                  </div>
                )}

                <div className="rounded-xl border border-dashed border-emerald-850 p-4 bg-[#021f18] text-center shrink-0">
                  <input 
                    type="file"
                    accept="image/*"
                    onChange={handleQrUploadLocal}
                    className="hidden"
                    id="setting-qr-upload"
                  />
                  <label 
                    htmlFor="setting-qr-upload"
                    className="inline-flex items-center space-x-1 rounded bg-emerald-900 hover:bg-emerald-800 text-white font-bold text-[10px] px-3 py-1.5 cursor-pointer shadow transition"
                  >
                    <Image className="h-3.5 w-3.5" />
                    <span>Upload New QR Image File</span>
                  </label>
                  <p className="text-[9px] text-emerald-450 mt-1.5">Accepts JPEG/PNG/WebP. Converts to base64 immediately for DB storage.</p>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-emerald-300 font-bold">Website Contact Number</label>
                <input 
                  type="text"
                  required
                  value={contactNumberSetting}
                  onChange={(e) => setContactNumberSetting(e.target.value)}
                  className="w-full rounded-lg border border-emerald-800 bg-[#021c16] px-3 py-2 text-white placeholder-emerald-850 focus:outline-none focus:border-emerald-500 h-9"
                  placeholder="e.g. +91 94460 01234"
                />
              </div>

              <div className="space-y-1">
                <label className="text-emerald-300 font-bold">Website Email Address</label>
                <input 
                  type="email"
                  required
                  value={contactEmailSetting}
                  onChange={(e) => setContactEmailSetting(e.target.value)}
                  className="w-full rounded-lg border border-emerald-800 bg-[#021c16] px-3 py-2 text-white placeholder-emerald-850 focus:outline-none focus:border-emerald-500 h-9"
                  placeholder="e.g. support@keralalottery.com"
                />
              </div>

              <div className="space-y-1">
                <label className="text-emerald-300 font-bold">WhatsApp Contact Number</label>
                <input 
                  type="text"
                  required
                  value={whatsappNumberSetting}
                  onChange={(e) => setWhatsappNumberSetting(e.target.value)}
                  className="w-full rounded-lg border border-emerald-800 bg-[#021c16] px-3 py-2 text-white placeholder-emerald-850 focus:outline-none focus:border-emerald-500 h-9"
                  placeholder="e.g. +91 94460 01234"
                />
              </div>

              {updatingSettings ? (
                <div className="flex items-center justify-center space-x-1.5 py-2 text-emerald-300">
                  <Loader2 className="h-4 w-4 animate-spin text-[#a3e635]" />
                  <span>Saving payment settings...</span>
                </div>
              ) : (
                <button
                  type="submit"
                  className="w-full flex items-center justify-center space-x-1.5 py-2.5 bg-[#a3e635] hover:bg-lime-500 text-slate-950 rounded-lg text-xs font-extrabold active:scale-95 transition shadow shadow-emerald-950/10"
                >
                  <Save className="h-4 w-4" />
                  <span>SAVE GATEWAY SETUP</span>
                </button>
              )}

            </form>
          </div>

          {/* Change Security passcode credentials */}
          <div className="rounded-2xl border border-emerald-900 bg-emerald-950/40 p-6 md:p-8 space-y-6 shadow-md flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-bold text-white uppercase border-b border-emerald-900 pb-2 flex items-center space-x-1.5">
                <Key className="h-4.5 w-4.5 text-amber-500" />
                <span>Replace Security Passcode</span>
              </h3>

              <form onSubmit={handleChangePasscode} className="space-y-4 text-xs pt-4">
                <div className="space-y-1">
                  <label className="text-emerald-300 font-bold block">Current Passcode</label>
                  <input 
                    type="password"
                    required
                    value={currentSecCode}
                    onChange={(e) => setCurrentSecCode(e.target.value)}
                    className="w-full rounded-lg border border-emerald-800 bg-[#021c16] px-3 py-2 text-white focus:outline-none focus:border-emerald-500 h-9 placeholder-emerald-850"
                    placeholder="••••••••"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-emerald-300 font-bold block">New Administrative Passcode</label>
                  <input 
                    type="password"
                    required
                    value={newSecCode}
                    onChange={(e) => setNewSecCode(e.target.value)}
                    className="w-full rounded-lg border border-emerald-800 bg-[#021c16] px-3 py-2 text-white focus:outline-none focus:border-emerald-500 h-9 placeholder-emerald-850"
                    placeholder="e.g. secure123"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full flex items-center justify-center space-x-1.5 py-2.5 bg-emerald-800 text-white rounded-lg text-xs font-bold hover:bg-emerald-700 active:scale-95 transition border border-emerald-600/30"
                >
                  <span>UPDATE PASSCODE ENTRY</span>
                </button>
              </form>
            </div>

            <div className="p-4 rounded-xl bg-[#021f18] border border-emerald-900/60 text-[11px] text-emerald-400 leading-relaxed mt-4">
              🛡️ <strong>Database Security Guidelines:</strong> Standard salt hashing is handled appropriately on server-side queries. Do not share credentials, and change custom strings routinely.
            </div>
          </div>

          {/* Full-width Hostinger Deployment & SQL Schema Export Desk */}
          <div className="md:col-span-2 rounded-2xl border border-amber-900 bg-[#021c16]/80 p-6 md:p-8 space-y-6 shadow-md text-left">
            <h3 className="text-sm font-bold text-amber-500 uppercase border-b border-emerald-900 pb-2 flex items-center space-x-2">
              <Download className="h-5 w-5 text-amber-500" />
              <span>Hostinger Node.js & MySQL Deployment Desk</span>
            </h3>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs leading-normal">
              
              {/* Step 1: Download Code & Database */}
              <div className="space-y-3 bg-emerald-950/20 p-4 rounded-xl border border-emerald-900/40">
                <p className="text-[#a3e635] font-extrabold uppercase text-[10px] tracking-wider">Step 1: Download ZIP Package</p>
                <p className="text-emerald-200">
                  Generate and download your sanitized web portal ZIP package containing all source code components, configuration scripts, and the full SQL database workspace!
                </p>
                
                <a 
                  href="/api/direct-zip-download"
                  download="kerala_lottery_portal_export.zip"
                  className="w-full inline-flex items-center justify-center space-x-2 py-3 bg-amber-500 hover:bg-[#b58c07] text-slate-950 font-black rounded-xl text-center shadow active:scale-95 transition"
                >
                  <Download className="h-4 w-4 stroke-[2.5]" />
                  <span>DOWNLOAD CODE ZIP BUNDLE</span>
                </a>
              </div>

              {/* Step 2: Import SQL Database */}
              <div className="space-y-2 bg-emerald-950/20 p-4 rounded-xl border border-emerald-900/40">
                <p className="text-[#a3e635] font-extrabold uppercase text-[10px] tracking-wider">Step 2: Setup Hostinger MySQL</p>
                <p className="text-emerald-200">
                  Create a new MySQL database name/user through your Hostinger hPanel and import the included database schema template.
                </p>
                <div className="bg-[#011410] rounded border border-emerald-800 p-2 font-mono text-[10.5px] text-emerald-300">
                  <p className="font-bold text-white mb-1">📁 Schema File Name:</p>
                  <p>kerala_lottery.sql (Included in root)</p>
                  <p className="mt-2 text-emerald-450 text-[10px]">Imports tables: `settings`, `tickets` with standard configurations.</p>
                </div>
              </div>

              {/* Step 3: Run Node.js Application */}
              <div className="space-y-2 bg-emerald-950/20 p-4 rounded-xl border border-emerald-900/40">
                <p className="text-[#a3e635] font-extrabold uppercase text-[10px] tracking-wider">Step 3: Setup hPanel Node App</p>
                <p className="text-emerald-200">
                  Configure a new Node.js Application block in your hPanel dashboard settings, upload the unpacked ZIP files, and write environment variables matching your db credentials:
                </p>
                
                <div className="bg-[#011410] rounded border border-emerald-800 p-2 font-mono text-[9px] text-emerald-300 space-y-1">
                  <p><span className="text-amber-500">DB_HOST</span>=your_hostinger_mysql_host</p>
                  <p><span className="text-amber-500">DB_USER</span>=your_database_user</p>
                  <p><span className="text-amber-500">DB_PASSWORD</span>=your_database_password</p>
                  <p><span className="text-amber-500">DB_NAME</span>=your_database_name</p>
                </div>
              </div>

            </div>
          </div>

        </div>
      )}

      {/* Verify / Assign lucky serials pop-up Modal */}
      {editingBooking && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="rounded-2xl border border-emerald-800 bg-[#02241b] p-6 max-w-md w-full shadow-2xl space-y-4 animate-scale-up text-left text-xs text-white">
            
            <div className="flex items-center justify-between border-b border-emerald-800/60 pb-2">
              <h3 className="text-sm font-bold text-amber-500 uppercase tracking-wide">
                🎟️ Verify Ticket & Allocate Serials
              </h3>
              <button 
                onClick={() => setEditingBooking(null)}
                className="text-emerald-400 hover:text-white font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-1 text-[11px] text-emerald-100 bg-emerald-950/80 p-3 rounded-lg border border-emerald-900">
              <p>👤 <strong>Buyer Name:</strong> {editingBooking.name}</p>
              <p>📞 <strong>Phone:</strong> {editingBooking.phone}</p>
              <p>🛒 <strong>Option Package:</strong> {editingBooking.packageName} ({editingBooking.ticketCount} tickets)</p>
              <p>💵 <strong>Amount Paid:</strong> Rs. {editingBooking.amount}</p>
            </div>

            <form onSubmit={handleVerifySubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="text-emerald-300 font-bold block">Assigned Lucky Ticket Serials (Comma Separated)</label>
                <input 
                  type="text"
                  required
                  value={assignedSerials}
                  onChange={(e) => {
                    const newVal = e.target.value;
                    setAssignedSerials(newVal);
                    // Dynamically set winning ticket option to first ticket default
                    const tkts = newVal.split(",").map(t => t.trim()).filter(Boolean);
                    if (tkts.length > 0 && winningTicket && winningTicket !== "All Tickets" && !tkts.includes(winningTicket)) {
                      setWinningTicket(tkts[0]);
                    }
                  }}
                  className="w-full rounded-lg border border-emerald-800 bg-[#021c16] px-3 py-2 text-white focus:outline-none focus:border-emerald-500 h-9 font-mono text-xs shadow-inner uppercase tracking-wider"
                  placeholder="e.g. W-690294, SS-102948, AK-102948"
                />
                <span className="text-[10px] text-emerald-450 italic mt-0.5 block">Assign exactly {editingBooking.ticketCount} ticket alphanumeric serial entries.</span>
              </div>

              {/* Award Winning Status section */}
              <div className="border-y border-emerald-800/30 py-3 space-y-3">
                <div className="flex items-center justify-between bg-emerald-950/40 p-2.5 rounded border border-emerald-900/60">
                  <div>
                    <span className="text-xs font-bold text-amber-400 uppercase block">🏆 Draw Winner Designation</span>
                    <span className="text-[9.5px] text-emerald-400">Designate this customer as an official prize drawer</span>
                  </div>
                  <input 
                    type="checkbox"
                    checked={isWinner}
                    onChange={(e) => {
                      const checked = e.target.checked;
                      setIsWinner(checked);
                      const tkts = assignedSerials.split(",").map(t => t.trim()).filter(Boolean);
                      const defaultTkt = tkts[0] || "Ticket";
                      
                      if (checked) {
                        setWinningTicket(defaultTkt);
                        setWinningPrizeState(`Won Lakhier Jackpot on Ticket ${defaultTkt}`);
                      } else {
                        setWinningPrizeState("Result Pending");
                      }
                    }}
                    className="h-5 w-5 accent-amber-500 cursor-pointer rounded"
                  />
                </div>

                {isWinner && (
                  <div className="space-y-3 bg-[#011410] rounded-xl p-3 border border-emerald-900 animate-scale-up">
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase font-bold text-amber-500 block">Select Winning Ticket Number</label>
                      <select
                        value={winningTicket}
                        onChange={(e) => {
                          const val = e.target.value;
                          setWinningTicket(val);
                          // Auto build prize string
                          const preset = winningPrizePreset || "Mega Jackpot (Rs. 25 Lakhs)";
                          setWinningPrizeState(`Won ${preset} on Ticket ${val}`);
                        }}
                        className="w-full rounded-md border border-emerald-800 bg-[#021c16] text-white px-2 py-1.5 focus:outline-none font-mono text-xs uppercase"
                      >
                        {assignedSerials.split(",").map(t => t.trim()).filter(Boolean).map((t, i) => (
                          <option key={i} value={t}>{t}</option>
                        ))}
                        <option value="All Tickets">All Purchased Tickets</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] uppercase font-bold text-amber-500 block">Select Prize Tier</label>
                      <select
                        value={winningPrizePreset}
                        onChange={(e) => {
                          const presetVal = e.target.value;
                          setWinningPrizePreset(presetVal);
                          const tkt = winningTicket || assignedSerials.split(",")[0]?.trim() || "Ticket";
                          if (presetVal === "custom") {
                            setWinningPrizeState(`Won Custom Prize on Ticket ${tkt}`);
                          } else {
                            setWinningPrizeState(`Won ${presetVal} on Ticket ${tkt}`);
                          }
                        }}
                        className="w-full rounded-md border border-emerald-800 bg-[#021c16] text-white px-2 py-1.5 focus:outline-none text-xs"
                      >
                        <option value="">-- Choose Preset Prize --</option>
                        <option value="1st Prize (Rs. 25 Crore)">1st Prize (Rs. 25 Crore)</option>
                        <option value="2nd Prize (Rs. 10 Crore)">2nd Prize (Rs. 10 Crore)</option>
                        <option value="3rd Prize (Rs. 75 Lakh)">3rd Prize (Rs. 75 Lakh)</option>
                        <option value="4th Prize (Rs. 25 Lakh)">4th Prize (Rs. 25 Lakh)</option>
                        <option value="5th Prize (Rs. 12 Lakhs)">5th Prize (Rs. 12 Lakhs)</option>
                        <option value="6th Prize (Rs. 8 Lakh)">6th Prize (Rs. 8 Lakh)</option>
                        <option value="7th Prize (Rs. 5 Lakh)">7th Prize (Rs. 5 Lakh)</option>
                        <option value="8th Prize (Rs. 3 Lakh)">8th Prize (Rs. 3 Lakh)</option>
                        <option value="9th Prize (Rs. 2 Lakh)">9th Prize (Rs. 2 Lakh)</option>
                        <option value="10th Prize (Rs. 75 Thousand)">10th Prize (Rs. 75 Thousand)</option>
                        <option value="custom">✍️ Custom Description...</option>
                      </select>
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-1">
                <label className="text-emerald-300 font-bold block">Final Display Winnings Text</label>
                <input 
                  type="text"
                  required
                  value={winningPrizeState}
                  onChange={(e) => setWinningPrizeState(e.target.value)}
                  className="w-full rounded-lg border border-emerald-800 bg-[#021c16] px-3 py-2 text-white focus:outline-none focus:border-emerald-500 h-9"
                  placeholder="e.g. Won 3rd Prize (Rs 5,000) or Result Pending"
                />
                <span className="text-[9.5px] text-emerald-450 italic mt-0.5 block">This text is directly displayed to the customer in Check Winnings section.</span>
              </div>

              <div className="flex items-center justify-end space-x-2 pt-2 border-t border-emerald-800/60">
                <button
                  type="button"
                  onClick={() => setEditingBooking(null)}
                  className="rounded px-3 py-1.5 rounded-lg font-bold bg-emerald-950 hover:bg-emerald-900 transition hover:text-white text-emerald-400 text-[11px]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={localLoading}
                  className="rounded px-4 py-1.5 rounded-lg font-extrabold bg-[#a3e635] hover:bg-lime-500 text-slate-950 text-[11px] transition shadow"
                >
                  {localLoading ? <Loader2 className="h-4 w-4 animate-spin mx-auto animate-pulse" /> : "Verify & Save Details"}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* Add manually offline customer ticket Modal */}
      {isAddingManual && (
        <div className="fixed inset-0 z-55 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="rounded-2xl border border-emerald-800 bg-[#02241b] p-6 max-w-md w-full shadow-2xl space-y-4 text-left text-xs text-white my-8 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between border-b border-emerald-800/60 pb-2">
              <h3 className="text-sm font-black text-amber-500 uppercase tracking-tight flex items-center space-x-1.5 animate-pulse">
                <span>➕ ADD OFFLINE CUSTOMER MANUALLY</span>
              </h3>
              <button 
                onClick={() => setIsAddingManual(false)}
                className="text-emerald-400 hover:text-white font-bold text-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleManualSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-emerald-300 font-bold block">Customer Name *</label>
                  <input 
                    type="text"
                    required
                    value={manualName}
                    onChange={(e) => setManualName(e.target.value)}
                    className="w-full rounded-lg border border-emerald-800 bg-[#021c16] px-3 py-2 text-white focus:outline-none focus:border-emerald-500 h-9"
                    placeholder="e.g. Anand Kumar"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-emerald-300 font-bold block">Phone Number *</label>
                  <input 
                    type="tel"
                    required
                    value={manualPhone}
                    onChange={(e) => setManualPhone(e.target.value)}
                    className="w-full rounded-lg border border-emerald-800 bg-[#021c16] px-3 py-2 text-white focus:outline-none focus:border-emerald-500 h-9 font-mono"
                    placeholder="e.g. 9876543210"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-emerald-300 font-bold block">Email address (Optional)</label>
                  <input 
                    type="email"
                    value={manualEmail}
                    onChange={(e) => setManualEmail(e.target.value)}
                    className="w-full rounded-lg border border-emerald-900/40 bg-[#021c16] px-3 py-2 text-white focus:outline-none focus:border-emerald-500 h-9"
                    placeholder="e.g. anand@gmail.com"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-emerald-300 font-bold block">State *</label>
                  <select
                    value={manualState}
                    onChange={(e) => setManualState(e.target.value)}
                    className="w-full rounded-lg border border-emerald-800 bg-[#021c16] px-2 py-2 text-white focus:outline-none focus:border-emerald-500 h-9"
                  >
                    <option value="Kerala">Kerala</option>
                    <option value="Tamil Nadu">Tamil Nadu</option>
                    <option value="Karnataka">Karnataka</option>
                    <option value="Andhra Pradesh">Andhra Pradesh</option>
                    <option value="Maharashtra">Maharashtra</option>
                    <option value="Delhi">Delhi</option>
                    <option value="Other">Other State</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-emerald-300 font-bold block">Option Package</label>
                <select
                  value={manualPackageName}
                  onChange={(e) => {
                    const pack = e.target.value;
                    setManualPackageName(pack);
                    if (pack === "1 TICKET SPECIAL") {
                      setManualTicketCount("1");
                      setManualAmount("149");
                    } else if (pack === "3 TICKETS COMBO") {
                      setManualTicketCount("3");
                      setManualAmount("298");
                    } else if (pack === "5 TICKETS VALUE PACK") {
                      setManualTicketCount("5");
                      setManualAmount("500");
                    } else if (pack === "10 TICKETS JUMBO PACK") {
                      setManualTicketCount("10");
                      setManualAmount("1000");
                    }
                  }}
                  className="w-full rounded-lg border border-emerald-800 bg-[#021c16] px-2 py-2 text-white focus:outline-none focus:border-emerald-500 h-9"
                >
                  <option value="1 TICKET SPECIAL">1 TICKET SPECIAL (1 Slip - Rs. 149)</option>
                  <option value="3 TICKETS COMBO">3 TICKETS COMBO (3 Slips - Rs. 298)</option>
                  <option value="5 TICKETS VALUE PACK">5 TICKETS VALUE PACK (5 Slips - Rs. 500)</option>
                  <option value="10 TICKETS JUMBO PACK">10 TICKETS JUMBO PACK (10 Slips - Rs. 1000)</option>
                  <option value="Offline Manual Custom">Custom Pack Option</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-emerald-300 font-bold block">Ticket Count (Quantity)</label>
                  <input 
                    type="number"
                    required
                    min={1}
                    value={manualTicketCount}
                    onChange={(e) => setManualTicketCount(e.target.value)}
                    className="w-full rounded-lg border border-emerald-800 bg-[#021c16] px-3 py-2 text-white focus:outline-none focus:border-emerald-500 h-9 font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-emerald-300 font-bold block">Total Amount Paid (Rs.)</label>
                  <input 
                    type="number"
                    required
                    min={0}
                    value={manualAmount}
                    onChange={(e) => setManualAmount(e.target.value)}
                    className="w-full rounded-lg border border-emerald-800 bg-[#021c16] px-3 py-2 text-white focus:outline-none focus:border-emerald-500 h-9 font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-emerald-300 font-bold block">Assigned Ticket Serials (Leave blank for auto-generate)</label>
                <input 
                  type="text"
                  value={manualTicketNumber}
                  onChange={(e) => setManualTicketNumber(e.target.value)}
                  className="w-full rounded-lg border border-emerald-800 bg-[#021c16] px-3 py-2 text-white focus:outline-none focus:border-emerald-500 h-9 font-mono text-xs uppercase tracking-wider"
                  placeholder="e.g. BR-102948, AK-395810"
                />
              </div>

              <div className="space-y-1">
                <label className="text-emerald-300 font-bold block">Winning Status / Prize description</label>
                <input 
                  type="text"
                  required
                  value={manualWinningPrize}
                  onChange={(e) => setManualWinningPrize(e.target.value)}
                  className="w-full rounded-lg border border-emerald-800 bg-[#021c16] px-3 py-2 text-white focus:outline-none focus:border-emerald-500 h-9 text-xs"
                  placeholder="Result Pending / Won custom prize"
                />
              </div>

              <div className="flex items-center justify-end space-x-2 pt-2 border-t border-emerald-800/60 flex-shrink-0">
                <button
                  type="button"
                  onClick={() => setIsAddingManual(false)}
                  className="rounded px-2.5 py-1.5 rounded-lg font-bold bg-emerald-950 hover:bg-emerald-900 transition hover:text-white text-emerald-400 text-[11px]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={localLoading}
                  className="rounded px-4 py-1.5 rounded-lg font-extrabold bg-amber-500 hover:bg-amber-400 text-slate-950 text-[11px] transition shadow"
                >
                  {localLoading ? <Loader2 className="h-4 w-4 animate-spin mx-auto animate-pulse" /> : "Save & Verify Offline Customer"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
