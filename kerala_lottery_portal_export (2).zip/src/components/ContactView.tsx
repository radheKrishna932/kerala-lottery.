/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Mail, Phone, MapPin, Send, MessageSquare, CheckCircle } from "lucide-react";

export default function ContactView() {
  const [settings, setSettings] = React.useState({
    contactNumber: "+91 94460 01234",
    contactEmail: "contact@keralalottery.com",
    whatsappNumber: "+91 94460 01234"
  });

  React.useEffect(() => {
    fetch("/api/settings")
      .then((res) => res.json())
      .then((data) => {
        setSettings({
          contactNumber: data.contactNumber || "+91 94460 01234",
          contactEmail: data.contactEmail || "contact@keralalottery.com",
          whatsappNumber: data.whatsappNumber || "+91 94460 01234"
        });
      })
      .catch((err) => console.error("Error loading settings in contact view:", err));
  }, []);

  const [formState, setFormState] = React.useState({
    name: "",
    phone: "",
    email: "",
    subject: "",
    message: ""
  });
  const [submitted, setSubmitted] = React.useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formState.name || !formState.phone || !formState.message) {
      alert("Please fill in your name, phone number, and message.");
      return;
    }
    // Simulate successful dispatch
    setSubmitted(true);
    // Reset form fields
    setFormState({ name: "", phone: "", email: "", subject: "", message: "" });
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6 md:px-8 space-y-12 animate-fade-in" id="contact-section">
      <div className="text-center space-y-3">
        <span className="inline-flex items-center space-x-1 rounded-full bg-emerald-950 px-3 py-1 text-xs font-semibold text-[#a3e635]">
          <MessageSquare className="h-4 w-4 text-amber-500" />
          <span>General Contact Support Grid</span>
        </span>
        <h1 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
          Get in Touch <span className="text-emerald-400">With Our Desk</span>
        </h1>
        <p className="mx-auto max-w-xl text-sm text-emerald-250">
          Have problems uploading screenshots, checking winner sheets, or claim guidelines? Contact our Palayam staff directly.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-10 md:grid-cols-5 items-stretch">
        {/* Contact Info Deck */}
        <div className="md:col-span-2 space-y-6 flex flex-col justify-between">
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-white tracking-tight border-b border-emerald-800 pb-2">
              Corporate Office Coordinates
            </h2>

            <div className="space-y-5 text-xs text-emerald-200">
              <div className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 shrink-0 text-amber-500" />
                <div className="space-y-1">
                  <p className="font-bold text-white">Directorate Office Address</p>
                  <p className="leading-relaxed">Vikas Bhavan, Palayam, Thiruvananthapuram, Kerala 695033, India.</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <Phone className="h-5 w-5 shrink-0 text-amber-500" />
                <div className="space-y-1">
                  <p className="font-bold text-white">Telephone Lines</p>
                  <p>
                    <a href={`tel:${settings.contactNumber}`} className="hover:underline hover:text-white">
                      {settings.contactNumber}
                    </a>
                  </p>
                  <p className="text-[10px] text-emerald-450">Active Mon-Sat: 10:00 AM - 5:00 PM</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <Mail className="h-5 w-5 shrink-0 text-amber-500" />
                <div className="space-y-1">
                  <p className="font-bold text-white">Electronic Support Box</p>
                  <p>
                    <a href={`mailto:${settings.contactEmail}`} className="hover:underline hover:text-white">
                      {settings.contactEmail}
                    </a>
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-emerald-900 bg-emerald-950/40 p-5 space-y-3">
            <h3 className="text-xs font-bold text-[#a3e635] uppercase tracking-wider">⚡ Instant Chat Resolution</h3>
            <p className="text-[11px] text-emerald-200">Connect with an agent who will verify your screen transactions or answer queries immediately.</p>
            <a 
              href={`https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, "")}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center space-x-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2 shadow transition animate-bounce"
            >
              <span>Launch WhatsApp Session</span>
            </a>
          </div>
        </div>

        {/* Contact Form Submission Area */}
        <div className="md:col-span-3 rounded-2xl border border-emerald-900/60 bg-emerald-950/20 p-6 md:p-8 shrink-0">
          {submitted ? (
            <div className="flex flex-col items-center justify-center text-center h-full py-12 space-y-4 animate-scale-up">
              <CheckCircle className="h-14 w-14 text-[#a3e635]" />
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-white">Inquiry Received Successfully!</h3>
                <p className="text-xs text-emerald-200 max-w-sm">
                  Thank you! Your questions are dispatched to our local Palayam queue. An official agent will return with responses on your WhatsApp or email shortly.
                </p>
              </div>
              <button 
                onClick={() => setSubmitted(false)}
                className="rounded-lg bg-emerald-800 text-white text-xs font-bold px-4 py-2 hover:bg-emerald-700 transition"
              >
                Send Another Message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <h3 className="text-sm font-bold text-white mb-2">Send an Electronic Inquiry</h3>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-1">
                  <label className="text-emerald-300 font-semibold">Your Name <span className="text-red-500">*</span></label>
                  <input 
                    type="text"
                    required
                    value={formState.name}
                    onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                    className="w-full rounded-lg border border-emerald-800/60 bg-emerald-955 px-3 py-2 text-white focus:outline-none focus:border-emerald-500 h-9"
                    placeholder="e.g. Adarsh Nair"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-emerald-300 font-semibold">WhatsApp Number <span className="text-red-500">*</span></label>
                  <input 
                    type="tel"
                    required
                    value={formState.phone}
                    onChange={(e) => setFormState({ ...formState, phone: e.target.value })}
                    className="w-full rounded-lg border border-emerald-800/60 bg-emerald-955 px-3 py-2 text-white focus:outline-none focus:border-emerald-500 h-9"
                    placeholder="e.g. +91 94460 00000"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-emerald-300 font-semibold">Email (Optional)</label>
                <input 
                  type="email"
                  value={formState.email}
                  onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                  className="w-full rounded-lg border border-emerald-800/60 bg-emerald-955 px-3 py-2 text-white focus:outline-none focus:border-emerald-500 h-9"
                  placeholder="e.g. adarsh@gmail.com"
                />
              </div>

              <div className="space-y-1">
                <label className="text-emerald-300 font-semibold">Subject Inquiry</label>
                <input 
                  type="text"
                  value={formState.subject}
                  onChange={(e) => setFormState({ ...formState, subject: e.target.value })}
                  className="w-full rounded-lg border border-emerald-800/60 bg-emerald-955 px-3 py-2 text-white focus:outline-none focus:border-emerald-500 h-9"
                  placeholder="e.g. Question on checking result / large claim limits"
                />
              </div>

              <div className="space-y-1">
                <label className="text-emerald-300 font-semibold">Message <span className="text-red-500">*</span></label>
                <textarea 
                  required
                  rows={4}
                  value={formState.message}
                  onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                  className="w-full rounded-lg border border-emerald-800/60 bg-emerald-955 px-3 py-2 text-white focus:outline-none focus:border-emerald-500 leading-relaxed"
                  placeholder="Enter details on your question here..."
                ></textarea>
              </div>

              <button 
                type="submit"
                className="w-full flex items-center justify-center space-x-1.5 rounded-lg bg-amber-500 active:scale-95 text-slate-950 px-4 py-2.5 hover:bg-[#b58c07] transition text-xs font-bold shadow-md shadow-amber-950/20"
              >
                <Send className="h-4 w-4" />
                <span>Dispatch Inquiry</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
