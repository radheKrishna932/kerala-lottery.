/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { LOTTERY_PACKAGES, TESTIMONIALS } from "../data";
import { Ticket, Search, TrendingUp, ShieldCheck, HelpCircle, ArrowRight, UserCheck, Calendar } from "lucide-react";

interface HomeViewProps {
  setCurrentPage: (page: string) => void;
  setSelectedPackageId: (id: string | null) => void;
  setQuickResultPhone: (phone: string) => void;
}

export default function HomeView({ setCurrentPage, setSelectedPackageId, setQuickResultPhone }: HomeViewProps) {
  const [phoneQuery, setPhoneQuery] = React.useState("");
  
  // Helper to calculate time remaining until next 3:00 PM IST (UTC +5:30)
  const calculateTimeTo3PM_IST = () => {
    const now = new Date();
    
    // Get actual UTC timestamp, then offset to Indian Standard Time (UTC + 5 hours 30 minutes)
    const utcTime = now.getTime() + (now.getTimezoneOffset() * 60000);
    const istTime = new Date(utcTime + (3600000 * 5.5));
    
    // Set target to today at 3:00 PM in IST
    const target = new Date(istTime);
    target.setHours(15, 0, 0, 0);
    
    // If current IST has already passed 3:00 PM, target is tomorrow at 3:00 PM IST
    if (istTime.getTime() >= target.getTime()) {
      target.setDate(target.getDate() + 1);
    }
    
    const diffMs = target.getTime() - istTime.getTime();
    const totalSeconds = Math.max(0, Math.floor(diffMs / 1000));
    
    const days = Math.floor(totalSeconds / (3600 * 24));
    const hours = Math.floor((totalSeconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    
    return { days, hours, minutes, seconds };
  };

  const [timeLeft, setTimeLeft] = React.useState(calculateTimeTo3PM_IST());

  React.useEffect(() => {
    // Update timer every single second
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeTo3PM_IST());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleBuyClick = (pkgId: string) => {
    setSelectedPackageId(pkgId);
    setCurrentPage("buy");
  };

  const handleQuickResultSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneQuery.trim()) {
      alert("Please enter a valid phone number used during checkout.");
      return;
    }
    setQuickResultPhone(phoneQuery);
    setCurrentPage("result");
  };

  return (
    <div className="space-y-16 pb-12 animate-fade-in" id="home-view-container">
      {/* Premium Hero Banner */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#022c22] via-[#043325] to-[#011c16] py-16 px-4 md:py-24 text-center border-b border-emerald-900/30">
        
        {/* Subtle dynamic background grids */}
        <div className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.06)_0,transparent_100%)]"></div>
        <div className="absolute top-10 right-10 z-0 scale-75 animate-pulse opacity-20">
          <TrendingUp className="h-64 w-64 text-emerald-500" />
        </div>

        <div className="relative z-10 mx-auto max-w-5xl space-y-8 px-4">
          
          {/* Subheader Badge */}
          <div className="inline-flex items-center space-x-1 px-3 py-1 rounded-full bg-emerald-900/60 border border-emerald-600/40 text-xs font-bold text-[#a3e635] shadow-md uppercase tracking-widest">
            <span className="inline-block h-2 w-2 rounded-full bg-amber-500 animate-ping"></span>
            <span>Bumper Drawing: Active Booking Open</span>
          </div>

          {/* Epic Main Heading */}
          <div className="space-y-4">
            <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl md:text-6xl uppercase">
              KERALA STATE <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-[#a3e635] to-amber-400">MEGA JACKPOT</span>
            </h1>
            <p className="mx-auto max-w-2xl text-xs sm:text-sm text-emerald-250 font-normal leading-relaxed">
              Book authentic government-issued physical paper lotteries. We purchase on your behalf, post ticket series to your phone registry, and settle prize claims straight to your account!
            </p>
          </div>

          {/* Countdown timer */}
          <div className="mx-auto max-w-xl space-y-3 rounded-2xl border border-emerald-700/60 bg-emerald-950/80 p-5 shadow-lg shadow-emerald-950/50">
            <p className="text-[11px] font-bold text-amber-500 uppercase tracking-widest">
              ⏳ CLOCK COUNTDOWN TO UPCOMING MEGA DRAWING
            </p>
            <div className="flex justify-center items-center space-x-4">
              {[
                { label: "DAYS", val: timeLeft.days },
                { label: "HOURS", val: timeLeft.hours },
                { label: "MINUTES", val: timeLeft.minutes },
                { label: "SECONDS", val: timeLeft.seconds }
              ].map((time, idx) => (
                <div key={idx} className="flex flex-col items-center">
                  <div className="flex items-center justify-center rounded-lg bg-emerald-900/80 border border-emerald-700/40 font-mono text-2xl font-bold text-white h-12 w-14 shadow-inner">
                    {time.val < 10 ? `0${time.val}` : time.val}
                  </div>
                  <span className="text-[9px] font-extrabold text-emerald-400 uppercase mt-1 tracking-wider">{time.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Call to Actions */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
            <button 
              onClick={() => handleBuyClick("pkg-3")}
              className="w-full sm:w-auto flex items-center justify-center space-x-2 rounded-xl bg-amber-500 active:scale-95 text-slate-950 px-6 py-3.5 hover:bg-[#b58c07] transition text-sm font-bold shadow-lg shadow-amber-950/30"
            >
              <Ticket className="h-5 w-5" />
              <span>BOOK BUMPER SPECIAL TICKET</span>
            </button>
            <button 
              onClick={() => setCurrentPage("result")}
              className="w-full sm:w-auto flex items-center justify-center space-x-1.5 rounded-xl border border-emerald-700 bg-emerald-900/30 text-emerald-100 hover:bg-emerald-900/50 text-sm font-semibold px-6 py-3.5 transition"
            >
              <Search className="h-4.5 w-4.5" />
              <span>Check My Draw Result</span>
            </button>
          </div>

          {/* Trust points banner */}
          <div className="grid grid-cols-2 gap-4 pt-10 border-t border-emerald-900/20 max-w-3xl mx-auto md:grid-cols-4">
            {[
              { icon: ShieldCheck, title: "100% Genuine", dsc: "Government Issued Paper Slips" },
              { icon: UserCheck, title: "Verified Bookings", dsc: "Linked to WhatsApp Registry" },
              { icon: TrendingUp, title: "Rs. 25 Crore Payout", dsc: "Eligible for standard jackspots" },
              { icon: Calendar, title: "Daily Live Draw", dsc: "Draws at 3:00 PM onwards" }
            ].map((pt, i) => (
              <div key={i} className="flex flex-col items-center text-center space-y-1">
                <pt.icon className="h-5 w-5 text-amber-500" />
                <h4 className="text-xs font-bold text-white">{pt.title}</h4>
                <p className="text-[10px] text-emerald-400">{pt.dsc}</p>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* Marquee Verified Live Winners */}
      <section className="-mt-16 bg-[#022c22]/90 border-y border-emerald-900/40 py-2">
        <div className="flex items-center space-x-4">
          <span className="bg-amber-500 text-slate-950 font-bold text-[10px] uppercase tracking-widest px-3 py-1 shrink-0 rounded-r shadow">
            🎉 LIVE WINNERS:
          </span>
          <marquee scrollamount="3" className="text-xs font-medium text-emerald-100">
            🏆 Ticket AK-294029 wins Rs. 10 Lakhs in Akshaya draw! • 🏆 Ticket FF-844910 wins Rs. 50,000 in Fifty-Fifty! • 🏆 Ticket KN-928340 wins Rs. 1.2 Crore bumper! Book your queue now to get listed.
          </marquee>
        </div>
      </section>

      {/* Ticket pricing bundles displaying */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8 space-y-8" id="quick-ticket">
        <div className="text-center space-y-2">
          <span className="text-[10px] font-bold text-amber-550 uppercase tracking-widest">
            🛒 TICKET PRICING AND VALUE BUNDLES
          </span>
          <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl uppercase">
            CHOOSE YOUR <span className="text-emerald-400">LOTTERY VOLUME</span>
          </h2>
          <p className="mx-auto max-w-lg text-xs text-emerald-250">
            Details fetched from keralastatemegajackpot.com/buy-ticket. Choose a multi-ticket combo and save heavily on service allocations.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {LOTTERY_PACKAGES.map((pkg) => (
            <div 
              key={pkg.id}
              className="flex flex-col justify-between rounded-2xl border border-emerald-900 bg-emerald-950/20 p-6 shadow-md transition duration-350 hover:border-[#16a34a] hover:-translate-y-1 hover:shadow-lg hover:shadow-emerald-950/40"
            >
              <div className="space-y-4">
                <div className="space-y-1">
                  <span className="text-[10px] text-amber-500 font-bold uppercase tracking-widest block">
                    {pkg.bonus}
                  </span>
                  <h3 className="text-md font-bold text-white tracking-tight">{pkg.name}</h3>
                </div>
                
                <div className="flex items-baseline space-x-1 border-y border-emerald-900/40 py-3">
                  <span className="text-sm font-bold text-[#a3e635]">Rs.</span>
                  <span className="text-3xl font-extrabold text-white leading-none">{pkg.price}</span>
                  <span className="text-xs text-emerald-450 font-medium ml-1">/ {pkg.ticketCount} {pkg.ticketCount === 1 ? 'ticket' : 'tickets'}</span>
                </div>

                <p className="text-[11px] leading-relaxed text-emerald-200/95 font-normal">
                  {pkg.description}
                </p>
              </div>

              <div className="pt-6">
                <button
                  onClick={() => handleBuyClick(pkg.id)}
                  className="w-full flex items-center justify-center space-x-1.5 rounded-lg bg-emerald-800 text-white text-xs font-bold py-2.5 transition cursor-pointer hover:bg-emerald-700 active:scale-95 shadow"
                >
                  <span>Select & Buy Now</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Quick check draw results lookup bar */}
      <section className="mx-auto max-w-5xl px-4 sm:px-6">
        <div className="rounded-3xl border border-emerald-900 bg-gradient-to-r from-emerald-950/80 via-emerald-950/70 to-emerald-950/80 p-8 md:p-10 shadow-lg relative overflow-hidden">
          
          <div className="absolute top-0 right-0 h-40 w-40 rounded-full bg-emerald-500/5 blur-3xl"></div>

          <div className="relative z-10 grid grid-cols-1 md:grid-cols-5 gap-8 items-center">
            
            <div className="md:col-span-3 space-y-3 text-left">
              <span className="bg-emerald-900 text-emerald-400 text-[9px] font-bold uppercase tracking-widest px-2.5 py-1 rounded">
                ⚡ LIVE RESULT PORTAL
              </span>
              <h3 className="text-xl font-bold text-white uppercase tracking-tight">
                CHECK DRAW WINNING STATS INSTANTLY
              </h3>
              <p className="text-xs text-emerald-200 leading-relaxed font-normal">
                Forgot your assigned codes or want to check if you won a Karunya, Sthree-Sakthi, or Pooja Bumper prize? Put your Billing Phone Number below to do a database scan!
              </p>
            </div>

            <div className="md:col-span-2">
              <form onSubmit={handleQuickResultSearch} className="space-y-3">
                <div className="space-y-1 text-left">
                  <label className="text-[11px] font-semibold text-emerald-300">WhatsApp Phone Number</label>
                  <input 
                    type="tel"
                    value={phoneQuery}
                    onChange={(e) => setPhoneQuery(e.target.value)}
                    required
                    placeholder="e.g. +91 9446000000"
                    className="w-full h-11 rounded-xl border border-emerald-800 bg-[#022c22] px-4 text-white placeholder-emerald-700 focus:outline-none focus:border-emerald-500 text-xs text-center font-bold"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full flex items-center justify-center space-x-1 bg-amber-500 active:scale-95 text-slate-950 h-11 rounded-xl text-xs font-bold hover:bg-[#b58c07] transition shadow-md"
                >
                  <Search className="h-4 w-4" />
                  <span>SEARCH WINNING SHEET</span>
                </button>
              </form>
            </div>

          </div>

        </div>
      </section>

      {/* High-quality responsive Testimonials grid */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 md:px-8 space-y-8">
        <div className="text-center space-y-2">
          <span className="text-[10px] font-bold text-amber-550 uppercase tracking-widest">
            💬 GENUINE CUSTOMER PATRONAGE
          </span>
          <h2 className="text-2xl font-bold text-white uppercase tracking-wide">
            TESTIMONIALS & <span className="text-emerald-400">WINNING REVIEWS</span>
          </h2>
          <p className="text-xs text-emerald-205 max-w-md mx-auto">
            Real stories shared by Non-Resident Keralites and local players who booked official bumper tickets and received payouts through this proxy app.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {TESTIMONIALS.map((t) => (
            <div 
              key={t.id}
              className="rounded-2xl border border-emerald-900 bg-emerald-950/30 p-6 flex flex-col justify-between space-y-6 shadow"
            >
              <div className="space-y-3">
                {/* Visual Stars */}
                <div className="flex space-x-0.5">
                  {[...Array(t.rating)].map((_, i) => (
                    <span key={i} className="text-amber-500 text-sm">★</span>
                  ))}
                </div>
                <p className="text-xs text-emerald-100/90 leading-relaxed font-normal">
                  "{t.text}"
                </p>
              </div>

              <div className="flex items-center space-x-3 pt-4 border-t border-emerald-900/45">
                <img 
                  src={t.avatarUrl} 
                  alt={t.name}
                  className="h-10 w-10 shrink-0 rounded-full border border-emerald-700"
                  referrerPolicy="no-referrer"
                />
                <div className="text-xs">
                  <h4 className="font-bold text-white">{t.name}</h4>
                  <p className="text-[10px] text-emerald-400">{t.location}</p>
                  <p className="text-[10px] font-semibold text-[#a3e635] uppercase mt-0.5">{t.prizeWon}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Accordion FAQ preview section */}
      <section className="mx-auto max-w-4xl px-4 text-center space-y-4">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider">Frequently Asked Questions</h3>
        <p className="text-xs text-emerald-300 max-w-md mx-auto leading-relaxed">Need quick information about delivery schedules or the legality of online proxy tickets? Visit our dedicated help page.</p>
        <button
          onClick={() => setCurrentPage("faq")}
          className="inline-flex items-center space-x-1.5 rounded-lg bg-emerald-900 hover:bg-emerald-800 text-white text-xs font-semibold px-4 py-2 border border-emerald-800/60 shadow"
        >
          <HelpCircle className="h-4 w-4 text-amber-500" />
          <span>Go to FAQ Help Desk</span>
        </button>
      </section>
    </div>
  );
}
