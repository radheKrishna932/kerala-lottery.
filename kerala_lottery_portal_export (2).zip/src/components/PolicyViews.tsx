/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { FAQS } from "../data";
import { HelpCircle, Shield, FileText, ChevronDown } from "lucide-react";

interface PolicyViewsProps {
  viewType: "faq" | "privacy" | "terms";
}

export default function PolicyViews({ viewType }: PolicyViewsProps) {
  const [openFaq, setOpenFaq] = React.useState<number | null>(null);

  const toggleFaq = (idx: number) => {
    setOpenFaq(openFaq === idx ? null : idx);
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 md:px-8">
      {viewType === "faq" && (
        <section className="space-y-8 animate-fade-in" id="faq-section">
          <div className="text-center space-y-2">
            <span className="inline-flex items-center space-x-1 rounded-full bg-emerald-950 px-3 py-1 text-xs font-semibold text-[#a3e635]">
              <HelpCircle className="h-4 w-4 text-amber-500" />
              <span>Got Questions? We Have Answers</span>
            </span>
            <h1 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
              Frequently Asked <span className="text-emerald-400">Questions</span>
            </h1>
            <p className="text-sm text-emerald-300">
              Clear, transparent documentation regarding online booking logistics, claiming verification mechanics, and draw parameters.
            </p>
          </div>

          <div className="space-y-4">
            {FAQS.map((faq, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div 
                  key={idx}
                  className="rounded-xl border border-emerald-900/60 bg-emerald-950/40 overflow-hidden transition-all duration-300"
                >
                  <button 
                    onClick={() => toggleFaq(idx)}
                    className="w-full flex items-center justify-between px-6 py-4 text-left text-sm font-bold text-white transition hover:bg-emerald-900/25"
                  >
                    <span>{faq.question}</span>
                    <ChevronDown className={`h-4.5 w-4.5 text-amber-400 transition-transform duration-300 ${isOpen ? "rotate-180" : ""}`} />
                  </button>
                  
                  {isOpen && (
                    <div className="px-6 pb-5 pt-1 text-xs text-emerald-200 leading-relaxed border-t border-emerald-900/20 bg-emerald-950/80">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="rounded-xl bg-gradient-to-r from-emerald-900/40 to-amber-900/20 p-6 border border-emerald-900/30 text-center space-y-3">
            <h3 className="text-sm font-bold text-white">Have other questions not listed here?</h3>
            <p className="text-xs text-emerald-200">Our customer desk is active on WhatsApp and Email to resolve any purchase issues within 10 minutes.</p>
            <div className="flex justify-center space-x-4">
              <a href="mailto:support@keralastatemegajackpot.com" className="rounded-md bg-emerald-700 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-600 transition">Email Support</a>
              <a href="https://wa.me/914712301740" className="rounded-md bg-amber-500 px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-amber-450 transition">WhatsApp Desk</a>
            </div>
          </div>
        </section>
      )}

      {viewType === "privacy" && (
        <section className="space-y-6 animate-fade-in" id="privacy-section">
          <div className="flex items-center space-x-3 border-b border-emerald-900/40 pb-4">
            <Shield className="h-8 w-8 text-amber-500" />
            <div>
              <h1 className="text-2xl font-bold text-white">Privacy Policy</h1>
              <p className="text-xs text-emerald-400 font-medium">Last updated: May 25, 2026</p>
            </div>
          </div>

          <div className="text-xs text-emerald-100 leading-relaxed space-y-4">
            <p>
              At <strong>Kerala State Mega Jackpot Proxy Portal</strong>, we respect your confidentiality. This Privacy Policy documents our practices regarding collection, safe storage, and usage of your personal particulars when bookings are made on our site.
            </p>

            <h3 className="text-sm font-bold text-white">1. Information We Collect</h3>
            <p>
              When purchasing tickets on our portal, you supply specific details, which are:
            </p>
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Personal particulars</strong>: Full Name, Active Email, and State of domicile.</li>
              <li><strong>Contact coordinates</strong>: Whatsapp or Phone number (crucial for verifying bookings and result reporting).</li>
              <li><strong>Transaction metadata</strong>: Screenshots of UPI completions submitted by you during checkout to verify transfers against our merchant accounts.</li>
            </ul>

            <h3 className="text-sm font-bold text-white">2. Handling & Storage Infrastructure</h3>
            <p>
              We operate an Express server that writes data to secure MySQL containers (u194092554_koll). No payment bank accounts, UPI pins, or credit details are recorded on our system as payments happen in your sovereign banking apps directly. Uploaded receipt photos are deleted automatically once tickets are verified and marked finalized by the admin.
            </p>

            <h3 className="text-sm font-bold text-white">3. Third-party Disclaimers</h3>
            <p>
              We absolutely do not trade, lease, or distribute your email or WhatsApp number to commercial marketers. Your details are shared solely with physical courier dispatchers or direct Directorate offices during heavy bumper jackpot claims as statutory requirement.
            </p>

            <h3 className="text-sm font-bold text-white">4. User Consent</h3>
            <p>
              By accessing our online queue and uploading payment receipts, you signify consent to our proxy booking and holding model.
            </p>
          </div>
        </section>
      )}

      {viewType === "terms" && (
        <section className="space-y-6 animate-fade-in" id="terms-section">
          <div className="flex items-center space-x-3 border-b border-emerald-900/40 pb-4">
            <FileText className="h-8 w-8 text-amber-500" />
            <div>
              <h1 className="text-2xl font-bold text-white">Terms & Conditions</h1>
              <p className="text-xs text-emerald-400 font-medium">Last updated: May 25, 2026</p>
            </div>
          </div>

          <div className="text-xs text-emerald-100 leading-relaxed space-y-4">
            <p>
              Welcome to the Kerala State Mega Jackpot ticketing portal. By placing booking orders on our platform, you conform fully to the legal terms of agreement listed here.
            </p>

            <h3 className="text-sm font-bold text-white">1. Service Definition (Proxy Agreement)</h3>
            <p>
              You acknowledge that our service operates strictly as a <strong>private physical purchase broker</strong>. When you book a ticket pack, you authorize our partners to visit physical lottery outlets in Kerala, pay for and buy authentic paper certificates. Our site DOES NOT operate private draws, or generate digital numbers.
            </p>

            <h3 className="text-sm font-bold text-white">2. Age eligibility & Geographic Restrictions</h3>
            <p>
              You must be at least 18 years of age to enter pools. Buying lotteries is limited to residents or states where lottery distribution holds state sanctions. Users from restricted states buy at their own discretion and we hold no liability for localized breaches.
            </p>

            <h3 className="text-sm font-bold text-white">3. Payment & Settlement Guidelines</h3>
            <p>
              All ticket purchase sales are final. Since money is deployed immediately to buy government physical paper slips, refunds or returns are impossible. You must upload exact screenshots within 1 hour of scanning UPI codes to allow timely allocations.
            </p>

            <h3 className="text-sm font-bold text-white">4. Result Reporting</h3>
            <p>
              While we update lucky ticket numbers in our registry database promptly, users are encouraged to cross-reference draw results on standard State Government Gazette sheets as well to prevent discrepancies. We are not responsible for typographical translation errors.
            </p>

            <h3 className="text-sm font-bold text-white">5. Governing jurisdiction</h3>
            <p>
              Any disputes related to allocations, prizes, or claims are bound strictly under the court jurisdictions of Thiruvananthapuram, Kerala, India.
            </p>
          </div>
        </section>
      )}
    </div>
  );
}
