/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Info, Award, Users, CheckCircle } from "lucide-react";

export default function AboutView() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6 md:px-8 space-y-12 animate-fade-in" id="about-section">
      {/* Intro Header */}
      <div className="text-center space-y-3">
        <span className="inline-flex items-center space-x-1 rounded-full bg-emerald-950 px-3 py-1 text-xs font-semibold text-[#a3e635]">
          <Info className="h-4 w-4 text-amber-500" />
          <span>Our Historical Journey & Mission</span>
        </span>
        <h1 className="text-3xl font-bold tracking-tight text-white sm:text-4xl md:text-5xl">
          About Kerala <span className="text-emerald-400">State Lotteries</span>
        </h1>
        <p className="mx-auto max-w-2xl text-sm text-emerald-200">
          Pioneering social welfare and financial transparency in India since 1967. Learn how we bridge the gap between physical draws and online trust.
        </p>
      </div>

      {/* Grid Layout of Pillars */}
      <div className="grid grid-cols-1 gap-8 md:grid-cols-2 items-center">
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-white tracking-tight border-b border-emerald-800 pb-2">
            The Historical Breakthrough (1967)
          </h2>
          <p className="text-xs text-emerald-200/90 leading-relaxed">
            In 1967, the late <strong>Finance Minister P. K. Kunju</strong> of Kerala achieved a remarkable milestone: he founded the first government-run lottery department in India. The vision was straightforward yet powerful—create sustainable employment for thousands of differently-abled or low-income vendors while raising critical revenue for building hospitals, roads, and public schools throughout the state.
          </p>
          <p className="text-xs text-emerald-200/90 leading-relaxed">
            By eliminating illegal private gambling rackets and formalizing games of chance under government regulation, Kerala created a shining template that many other Indian states later adopted. Today, the department publishes daily lists at 3:00 PM, maintaining pure transparency.
          </p>
        </div>

        <div className="relative h-64 rounded-2xl overflow-hidden border border-emerald-800 bg-gradient-to-r from-emerald-900 to-emerald-950 p-[2px] shadow-lg">
          <img 
            src="https://picsum.photos/seed/kerala-culture/850/600" 
            alt="Beautiful Kerala Traditional landscape houseboat illustration" 
            className="h-full w-full object-cover rounded-2xl opacity-80"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-emerald-950 via-emerald-950/20 to-transparent p-6 flex flex-col justify-end">
            <span className="text-[10px] uppercase tracking-widest text-[#a3e635] font-bold">Kerala Lotteries</span>
            <span className="text-sm font-bold text-white">Raising Lives While Raising Hopes</span>
          </div>
        </div>
      </div>

      {/* Stats Board & Value Proposition */}
      <div className="bg-gradient-to-r from-emerald-950/50 via-emerald-900/30 to-emerald-950/50 p-8 rounded-2xl border border-emerald-900/40 grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
        <div className="space-y-2">
          <Award className="h-8 w-8 text-amber-500 mx-auto" strokeWidth={1.5} />
          <h3 className="text-lg font-bold text-white uppercase tracking-wider">1967</h3>
          <p className="text-xs text-emerald-300">Established as India's very first sovereign department lottery scheme</p>
        </div>
        <div className="space-y-2 border-y border-emerald-800/20 py-6 md:border-y-0 md:border-x md:py-0">
          <Users className="h-8 w-8 text-amber-500 mx-auto" strokeWidth={1.5} />
          <h3 className="text-lg font-bold text-white uppercase tracking-wider">Rs. 25 Crore</h3>
          <p className="text-xs text-[#a3e635]">Thiruvonam Bumper Grand First Prize - India's highest jackpot payout!</p>
        </div>
        <div className="space-y-2">
          <CheckCircle className="h-8 w-8 text-amber-500 mx-auto" strokeWidth={1.5} />
          <h3 className="text-lg font-bold text-white uppercase tracking-wider">Karunya Fund</h3>
          <p className="text-xs text-emerald-300">Over 10 Lakh poor citizens received free surgery & medicine funding</p>
        </div>
      </div>

      {/* Online Proxy Solution Explanation */}
      <div className="space-y-4 max-w-3xl mx-auto text-center border-t border-emerald-900/20 pt-8">
        <h2 className="text-lg font-bold text-amber-400">Why Book Your Tickets Through Us?</h2>
        <p className="text-xs text-emerald-200/90 leading-relaxed">
          While millions of residents can purchase lotteries from street side booths, hundreds of Non-Resident Keralites (NRK) and nationwide patrons miss out due to a lack of safe digital portals. We solve this problem. Our platform coordinates safe proxy booking. We physically purchase the physical coupons on your behalf, upload their numbers, and store them securely until draw completion. If you win, we handle claims collection, protecting your luck comprehensively!
        </p>
      </div>
    </div>
  );
}
