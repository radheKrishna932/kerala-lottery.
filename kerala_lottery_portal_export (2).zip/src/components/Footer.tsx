/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Mail, Phone, MapPin, ShieldAlert, FileText, HelpCircle } from "lucide-react";

interface FooterProps {
  setCurrentPage: (page: string) => void;
}

export default function Footer({ setCurrentPage }: FooterProps) {
  const [settings, setSettings] = React.useState({
    contactNumber: "+91 94460 01234",
    contactEmail: "contact@keralalottery.com"
  });

  React.useEffect(() => {
    fetch("/api/settings")
      .then((res) => res.json())
      .then((data) => {
        setSettings({
          contactNumber: data.contactNumber || "+91 94460 01234",
          contactEmail: data.contactEmail || "contact@keralalottery.com"
        });
      })
      .catch((err) => console.error("Error loading settings in footer:", err));
  }, []);

  return (
    <footer className="w-full bg-[#022c22] border-t border-emerald-950 text-emerald-100">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 md:px-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          
          {/* Brand Presentation */}
          <div className="space-y-4">
            <h2 className="text-lg font-bold text-white tracking-wide">
              KERALA STATE <span className="text-emerald-400">LOTTERIES</span>
            </h2>
            <p className="text-xs text-emerald-300/80 leading-relaxed">
              Serving as a reliable digital proxy desk for registering and managing official Kerala State Lottery daily drawings. Your trusted sweepstake partner since 2018.
            </p>
            <p className="text-[10px] text-amber-500 font-semibold uppercase tracking-wider">
              🛡️ Official Directorate Proxy Bookings
            </p>
          </div>

          {/* Quick Navigational links */}
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4 border-b border-emerald-800/40 pb-2">
              Explore Services
            </h3>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => setCurrentPage("buy")} className="hover:text-amber-400 hover:underline text-left">
                  🎟️ Book Bumper Ticket
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage("result")} className="hover:text-amber-400 hover:underline text-left">
                  🔍 Check Drawing Results
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage("about")} className="hover:text-amber-400 hover:underline text-left">
                  ℹ️ Who We Are (About Us)
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage("blog")} className="hover:text-amber-400 hover:underline text-left">
                  📰 Learn State Logistics (Blog)
                </button>
              </li>
            </ul>
          </div>

          {/* Policies & Compliance */}
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4 border-b border-emerald-800/40 pb-2">
              Legal & Support
            </h3>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => setCurrentPage("faq")} className="flex items-center space-x-1.5 hover:text-amber-400 text-left">
                  <HelpCircle className="h-3.5 w-3.5 text-emerald-400" />
                  <span>FAQ & Help Desk</span>
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage("privacy")} className="flex items-center space-x-1.5 hover:text-amber-400 text-left">
                  <ShieldAlert className="h-3.5 w-3.5 text-emerald-400" />
                  <span>Privacy Policy</span>
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage("terms")} className="flex items-center space-x-1.5 hover:text-amber-400 text-left">
                  <FileText className="h-3.5 w-3.5 text-emerald-400" />
                  <span>Terms & Conditions</span>
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentPage("admin")} className="hover:text-amber-400 hover:underline text-left text-slate-400 text-[11px]">
                  ⚙️ Admin Panel Access
                </button>
              </li>
              <li className="pt-1.5 border-t border-emerald-900/40">
                <a href="/api/direct-zip-download" className="inline-flex items-center space-x-1.5 text-[#a3e635] hover:text-lime-400 font-extrabold text-[11.5px] uppercase tracking-wide">
                  <span>📥 DOWNLOAD PORTAL SOURCE ZIP</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Direct Address Point */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider border-b border-emerald-800/40 pb-2">
              Contact Desk
            </h3>
            <div className="space-y-2 text-xs">
              <div className="flex items-start space-x-2">
                <MapPin className="h-4 w-4 shrink-0 text-amber-500" />
                <span>Palayam, Thiruvananthapuram, Kerala 695033, India.</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="h-4 w-4 text-amber-500" strokeWidth={2.5} />
                <a href={`mailto:${settings.contactEmail}`} className="hover:underline hover:text-white">
                  {settings.contactEmail}
                </a>
              </div>
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4 text-amber-500" />
                <a href={`tel:${settings.contactNumber}`} className="hover:underline hover:text-white">
                  {settings.contactNumber}
                </a>
              </div>
            </div>
          </div>

        </div>

        <div className="mt-12 border-t border-emerald-950 pt-6 text-center text-xs text-emerald-400/60 leading-relaxed">
          <p>© {new Date().getFullYear()} Kerala State Mega Jackpot Proxy Portal. All rights reserved.</p>
          <p className="mt-2 text-[10px] text-emerald-500/50 max-w-3xl mx-auto">
            Disclaimers: We operate solely as an administrative proxy service purchasing paper-form certificates from registered agents within the state of Kerala. This website is not the official Directorate of Kerala State Lotteries website, and we hold no affiliation with government departments. Must be 18+ to enter.
          </p>
        </div>
      </div>
    </footer>
  );
}
