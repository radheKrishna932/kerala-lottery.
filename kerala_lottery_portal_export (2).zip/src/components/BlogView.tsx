/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { BLOGS } from "../data";
import { BlogPost } from "../types";
import { BookOpen, Calendar, ArrowLeft, ChevronRight } from "lucide-react";

export default function BlogView() {
  const [selectedPost, setSelectedPost] = React.useState<BlogPost | null>(null);

  if (selectedPost) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6 md:px-8 space-y-6 animate-fade-in">
        <button 
          onClick={() => setSelectedPost(null)}
          className="inline-flex items-center space-x-1 text-xs font-semibold text-emerald-450 hover:text-amber-400 hover:underline transition mb-2"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Articles list</span>
        </button>

        <div className="space-y-4">
          <div className="flex items-center space-x-2 text-xs text-emerald-300">
            <Calendar className="h-3.5 w-3.5 text-amber-505" />
            <span>{selectedPost.date}</span>
            <span>•</span>
            <span className="text-[#a3e635] font-semibold">Kerala State Mega Tutorial</span>
          </div>

          <h1 className="text-2xl font-bold text-white sm:text-3xl leading-tight">
            {selectedPost.title}
          </h1>

          <div className="rounded-2xl overflow-hidden border border-emerald-900 bg-emerald-950/40 p-1">
            <img 
              src={selectedPost.image} 
              alt={selectedPost.title} 
              className="w-full h-64 md:h-80 object-cover rounded-xl opacity-90"
              referrerPolicy="no-referrer"
            />
          </div>

          <div className="text-xs md:text-sm text-emerald-100/90 leading-relaxed font-normal space-y-4 pt-4 whitespace-pre-line border-t border-emerald-900/20">
            {selectedPost.content}
          </div>
        </div>

        <div className="border-t border-emerald-900/30 pt-6 flex items-center justify-between">
          <span className="text-[11px] text-emerald-400">Written by Kerala State Megajackpot Expert Panel</span>
          <button 
            onClick={() => setSelectedPost(null)}
            className="rounded-lg bg-emerald-900 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-800 transition"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6 md:px-8 space-y-10 animate-fade-in" id="blog-section">
      <div className="text-center space-y-3">
        <span className="inline-flex items-center space-x-1 rounded-full bg-emerald-950 px-3 py-1 text-xs font-semibold text-[#a3e635]">
          <BookOpen className="h-4 w-4 text-amber-500" />
          <span>Resource Center & Tips</span>
        </span>
        <h1 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
          Lottery Insights & <span className="text-emerald-400">Daily Updates</span>
        </h1>
        <p className="mx-auto max-w-xl text-sm text-emerald-250">
          Stay informed on draw allocations, procedural claiming guides, and safety tips from the legal desk on keralastatemegajackpot.com.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
        {BLOGS.map((post) => (
          <article 
            key={post.id}
            className="flex flex-col rounded-2xl border border-emerald-900/60 bg-emerald-950/30 overflow-hidden shadow-lg transition duration-300 hover:border-emerald-600/50 hover:translate-y-[-4px]"
          >
            <div className="h-48 w-full overflow-hidden relative">
              <img 
                src={post.image} 
                alt={post.title} 
                className="w-full h-full object-cover transition duration-500 hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <span className="absolute top-3 left-3 bg-emerald-950/80 backdrop-blur-md text-[#a3e635] text-[10px] font-bold px-2 py-1 rounded border border-emerald-700/60 uppercase tracking-widest">
                Guide
              </span>
            </div>

            <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <span className="text-[10px] text-amber-500 font-semibold uppercase tracking-wider">{post.date}</span>
                <h3 className="text-sm font-bold text-white tracking-tight leading-snug line-clamp-2">
                  {post.title}
                </h3>
                <p className="text-xs text-emerald-200/80 leading-relaxed line-clamp-3">
                  {post.summary}
                </p>
              </div>

              <button
                onClick={() => setSelectedPost(post)}
                className="inline-flex items-center space-x-1 text-xs font-bold text-emerald-400 hover:text-amber-400 transition"
              >
                <span>Read Full Guide</span>
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
